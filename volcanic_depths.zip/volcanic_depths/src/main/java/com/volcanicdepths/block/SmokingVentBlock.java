package com.volcanicdepths.block;

import com.volcanicdepths.effects.VolcanicDamage;
import com.volcanicdepths.effects.VolcanicEffects;
import com.volcanicdepths.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.AABB;

/**
 * A fumarole. Leaks smoke constantly (client only) and now and then performs a small, telegraphed burst:
 * a short hiss + glowing top face, then a puff of scorching steam about 3 blocks tall.
 */
public class SmokingVentBlock extends Block {
    public static final BooleanProperty ACTIVE = BooleanProperty.create("active");

    public static final int EVT_WARN = 1;
    public static final int EVT_BURST = 2;

    private static final int WARN_TICKS = 16;
    private static final int ACTIVE_RADIUS = 40;
    private static final int MAX_HEIGHT = 3;
    private static final float DAMAGE = 2.0F;

    public SmokingVentBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(ACTIVE, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ACTIVE);
    }

    @Override
    protected boolean isRandomlyTicking(BlockState state) {
        return !state.getValue(ACTIVE);
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(ACTIVE)) return;
        if (!level.hasNearbyAlivePlayer(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ACTIVE_RADIUS)) return;
        if (SuperheatedMagmaBlock.ventHeight(level, pos, MAX_HEIGHT) < 1) return;
        level.setBlock(pos, state.setValue(ACTIVE, true), Block.UPDATE_ALL);
        level.scheduleTick(pos, this, WARN_TICKS);
        level.blockEvent(pos, this, EVT_WARN, 0);
        level.playSound(null, pos, ModSounds.VENT_WARN.get(), SoundSource.BLOCKS, 0.8F, 0.9F + random.nextFloat() * 0.3F);
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.getValue(ACTIVE)) return;
        int height = SuperheatedMagmaBlock.ventHeight(level, pos, MAX_HEIGHT);
        level.setBlock(pos, state.setValue(ACTIVE, false), Block.UPDATE_ALL);
        if (height < 1) return;
        level.blockEvent(pos, this, EVT_BURST, height);
        level.playSound(null, pos, ModSounds.VENT_BURST.get(), SoundSource.BLOCKS, 1.2F, 0.9F + random.nextFloat() * 0.2F);

        AABB column = new AABB(pos.getX() + 0.1, pos.getY() + 1.0, pos.getZ() + 0.1,
                pos.getX() + 0.9, pos.getY() + 1.0 + height, pos.getZ() + 0.9);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, column, EntitySelector.NO_SPECTATORS)) {
            if (VolcanicDamage.isHeatImmune(e)) continue;
            e.hurt(VolcanicDamage.source(level, VolcanicDamage.SCALDING), DAMAGE);
            e.igniteForSeconds(2.0F);
        }
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        VolcanicDamage.scald(level, entity, 1.0F, 20, 0.0F);
        super.stepOn(level, pos, state, entity);
    }

    @Override
    protected boolean triggerEvent(BlockState state, Level level, BlockPos pos, int id, int param) {
        if (level.isClientSide) VolcanicEffects.ventEvent(level, pos, id, param);
        return true;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        VolcanicEffects.ventAmbient(level, pos, state.getValue(ACTIVE), random);
    }
}
