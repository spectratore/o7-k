package com.volcanicdepths.block;

import com.volcanicdepths.effects.VolcanicDamage;
import com.volcanicdepths.effects.VolcanicEffects;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Hot volcanic rock: periodic burn damage to anything standing on it, plus steam on the client. */
public class ScaldingRockBlock extends Block {
    private static final float DAMAGE = 2.0F;
    private static final int INTERVAL_TICKS = 20;

    public ScaldingRockBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        VolcanicDamage.scald(level, entity, DAMAGE, INTERVAL_TICKS, 1.0F);
        super.stepOn(level, pos, state, entity);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        VolcanicEffects.scaldingRockAmbient(level, pos, random);
    }
}
