package com.volcanicdepths.block;

import com.volcanicdepths.effects.VolcanicDamage;
import com.volcanicdepths.effects.VolcanicEffects;
import com.volcanicdepths.entity.MagmaDroplet;
import com.volcanicdepths.registry.ModEntities;
import com.volcanicdepths.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Superheated Magma: a rare block that periodically erupts into a Magma Geyser.
 *
 * <p>Everything is a server-side state machine driven by random ticks (to start a cycle) and scheduled ticks
 * (to advance it), so there is no block entity and nothing ticks unless a cycle is running:
 * <pre>
 *   DORMANT  --random tick (1 in ERUPTION_CHANCE, player nearby, open sky above)--&gt;
 *   RUMBLING (2.0 s, low rumble, smoke and sparks)  --&gt;
 *   CHARGING (1.5 s, pressure hiss, white-hot, many sparks)  --&gt;
 *   ERUPTING (8 pulses x 3 ticks, damage + launch + droplets)  --&gt;
 *   COOLING  (20 s cooldown, dim and crusted, cannot erupt)  --&gt;  DORMANT
 * </pre>
 * Light level and texture both change with the phase, so the warning is readable even without sound.
 * Visuals are sent to clients as block events and rendered in {@link VolcanicEffects}.
 */
public class SuperheatedMagmaBlock extends Block {
    public enum Phase implements StringRepresentable {
        DORMANT("dormant"), RUMBLING("rumbling"), CHARGING("charging"), ERUPTING("erupting"), COOLING("cooling");

        private final String name;

        Phase(String name) {
            this.name = name;
        }

        @Override
        public String getSerializedName() {
            return name;
        }
    }

    public static final EnumProperty<Phase> PHASE = EnumProperty.create("phase", Phase.class);
    public static final IntegerProperty PULSE = IntegerProperty.create("pulse", 0, 7);

    // Block event ids (client visuals)
    public static final int EVT_RUMBLE = 1;
    public static final int EVT_CHARGE = 2;
    public static final int EVT_ERUPT = 3;
    public static final int EVT_COOL = 4;

    // ---- tuning -------------------------------------------------------------------------------------------
    /** 1-in-N chance that a random tick on a dormant block starts a cycle. Lower = more frequent. */
    private static final int ERUPTION_CHANCE = 2;
    /** Blocks only start eruptions when a player is this close (keeps distant chunks quiet and cheap). */
    private static final int ACTIVE_RADIUS = 48;
    private static final int RUMBLE_TICKS = 40;
    private static final int CHARGE_TICKS = 30;
    private static final int PULSE_INTERVAL = 3;
    private static final int MAX_PULSE = 7;
    private static final int COOLDOWN_TICKS = 400;
    private static final int MAX_HEIGHT = 16;
    private static final int LIFT_PULSES = 3;
    private static final float GEYSER_DAMAGE = 3.0F;

    public SuperheatedMagmaBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(PHASE, Phase.DORMANT).setValue(PULSE, 0));
    }

    public static int lightFor(BlockState state) {
        return switch (state.getValue(PHASE)) {
            case DORMANT -> 9;
            case RUMBLING -> 11;
            case CHARGING -> 13;
            case ERUPTING -> 15;
            case COOLING -> 5;
        };
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(PHASE, PULSE);
    }

    /** Number of open blocks above {@code pos} (stops at the first full block), capped at {@code max}. */
    public static int ventHeight(BlockGetter level, BlockPos pos, int max) {
        BlockPos.MutableBlockPos m = pos.mutable();
        int h = 0;
        for (int i = 1; i <= max; i++) {
            m.setY(pos.getY() + i);
            if (level.getBlockState(m).isCollisionShapeFullBlock(level, m)) break;
            h = i;
        }
        return h;
    }

    // ---- server logic -------------------------------------------------------------------------------------
    @Override
    protected boolean isRandomlyTicking(BlockState state) {
        return state.getValue(PHASE) == Phase.DORMANT;
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(PHASE) != Phase.DORMANT) return;
        if (random.nextInt(ERUPTION_CHANCE) != 0) return;
        if (!level.hasNearbyAlivePlayer(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ACTIVE_RADIUS)) return;
        if (ventHeight(level, pos, MAX_HEIGHT) < 2) return; // buried or capped: never erupts

        level.setBlock(pos, state.setValue(PHASE, Phase.RUMBLING), Block.UPDATE_ALL);
        level.scheduleTick(pos, this, RUMBLE_TICKS);
        level.blockEvent(pos, this, EVT_RUMBLE, 0);
        level.playSound(null, pos, ModSounds.MAGMA_RUMBLE.get(), SoundSource.BLOCKS, 1.4F, 0.85F + random.nextFloat() * 0.3F);
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        switch (state.getValue(PHASE)) {
            case RUMBLING -> {
                if (ventHeight(level, pos, MAX_HEIGHT) < 2) {
                    abort(level, pos, state);
                    return;
                }
                level.setBlock(pos, state.setValue(PHASE, Phase.CHARGING), Block.UPDATE_ALL);
                level.scheduleTick(pos, this, CHARGE_TICKS);
                level.blockEvent(pos, this, EVT_CHARGE, 0);
                level.playSound(null, pos, ModSounds.MAGMA_CHARGE.get(), SoundSource.BLOCKS, 1.5F, 0.9F + random.nextFloat() * 0.2F);
            }
            case CHARGING -> {
                int height = ventHeight(level, pos, MAX_HEIGHT);
                if (height < 2) {
                    abort(level, pos, state);
                    return;
                }
                level.setBlock(pos, state.setValue(PHASE, Phase.ERUPTING).setValue(PULSE, 0), Block.UPDATE_ALL);
                erupt(level, pos, 0, height, random);
                level.scheduleTick(pos, this, PULSE_INTERVAL);
            }
            case ERUPTING -> {
                int pulse = state.getValue(PULSE);
                if (pulse < MAX_PULSE) {
                    level.setBlock(pos, state.setValue(PULSE, pulse + 1), Block.UPDATE_ALL);
                    erupt(level, pos, pulse + 1, ventHeight(level, pos, MAX_HEIGHT), random);
                    level.scheduleTick(pos, this, PULSE_INTERVAL);
                } else {
                    level.setBlock(pos, state.setValue(PHASE, Phase.COOLING).setValue(PULSE, 0), Block.UPDATE_ALL);
                    level.blockEvent(pos, this, EVT_COOL, 0);
                    level.scheduleTick(pos, this, COOLDOWN_TICKS);
                }
            }
            case COOLING -> level.setBlock(pos, defaultBlockState(), Block.UPDATE_ALL);
            default -> { }
        }
    }

    private void abort(ServerLevel level, BlockPos pos, BlockState state) {
        level.setBlock(pos, state.setValue(PHASE, Phase.COOLING).setValue(PULSE, 0), Block.UPDATE_ALL);
        level.scheduleTick(pos, this, COOLDOWN_TICKS / 4);
    }

    private void erupt(ServerLevel level, BlockPos pos, int pulse, int height, RandomSource random) {
        if (height < 1) return;
        level.blockEvent(pos, this, EVT_ERUPT, height);
        if (pulse == 0) {
            level.playSound(null, pos, ModSounds.GEYSER_ERUPT.get(), SoundSource.BLOCKS, 2.5F, 0.85F + random.nextFloat() * 0.2F);
        }
        if (pulse % 3 == 0) {
            level.playSound(null, pos, ModSounds.GEYSER_HISS.get(), SoundSource.BLOCKS, 1.6F, 0.8F + random.nextFloat() * 0.3F);
        }

        AABB column = new AABB(pos.getX() - 0.1, pos.getY() + 1.0, pos.getZ() - 0.1,
                pos.getX() + 1.1, pos.getY() + 1.0 + height, pos.getZ() + 1.1);
        DamageSource source = VolcanicDamage.source(level, VolcanicDamage.GEYSER);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, column, EntitySelector.NO_SPECTATORS)) {
            if (VolcanicDamage.isHeatImmune(e)) continue;
            e.hurt(source, GEYSER_DAMAGE);
            e.igniteForSeconds(4.0F);
            if (pulse <= LIFT_PULSES) { // a short, survivable shove upward (fall distance reset so it isn't a trap)
                Vec3 v = e.getDeltaMovement();
                e.setDeltaMovement(v.x, Math.max(v.y, Math.min(v.y + 0.2, 0.45)), v.z);
                e.hurtMarked = true;
                e.resetFallDistance();
            }
        }

        if ((pulse == 1 || pulse == 4) && height >= 3) {
            for (int i = 0; i < 2; i++) {
                MagmaDroplet droplet = new MagmaDroplet(ModEntities.MAGMA_DROPLET.get(), level);
                droplet.setPos(pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5);
                droplet.setDeltaMovement((random.nextDouble() - 0.5) * 0.3, 0.55 + random.nextDouble() * 0.35,
                        (random.nextDouble() - 0.5) * 0.3);
                level.addFreshEntity(droplet);
            }
        }
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        VolcanicDamage.scald(level, entity, 3.0F, 20, 3.0F);
        super.stepOn(level, pos, state, entity);
    }

    // ---- client visuals -----------------------------------------------------------------------------------
    @Override
    protected boolean triggerEvent(BlockState state, Level level, BlockPos pos, int id, int param) {
        if (level.isClientSide) VolcanicEffects.magmaEvent(level, pos, id, param);
        return true;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        VolcanicEffects.magmaAmbient(level, pos, state.getValue(PHASE), random);
    }
}
