package com.volcanicdepths.effects;

import com.volcanicdepths.VolcanicDepths;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/**
 * Server-side damage helpers. All three damage types are in the minecraft:is_fire tag, so Fire Resistance,
 * fire-immune mobs and fire protection enchantments work with them out of the box.
 */
public final class VolcanicDamage {
    public static final ResourceKey<DamageType> SCALDING = key("scalding");
    public static final ResourceKey<DamageType> GEYSER = key("geyser");
    public static final ResourceKey<DamageType> MAGMA_DROPLET = key("magma_droplet");

    private static ResourceKey<DamageType> key(String name) {
        return ResourceKey.create(Registries.DAMAGE_TYPE, VolcanicDepths.id(name));
    }

    public static DamageSource source(Level level, ResourceKey<DamageType> key) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(key));
    }

    public static boolean isHeatImmune(Entity entity) {
        return entity.fireImmune()
                || (entity instanceof LivingEntity living && living.hasEffect(MobEffects.FIRE_RESISTANCE));
    }

    /** Periodic contact damage for hot surfaces. Sneaking avoids it (same rule as vanilla magma blocks). */
    public static void scald(Level level, Entity entity, float amount, int intervalTicks, float igniteSeconds) {
        if (level.isClientSide || !(entity instanceof LivingEntity living)) return;
        if (entity.isSteppingCarefully() || isHeatImmune(entity)) return;
        if (entity.tickCount % intervalTicks != 0) return;
        living.hurt(source(level, SCALDING), amount);
        if (igniteSeconds > 0) living.igniteForSeconds(igniteSeconds);
    }

    private VolcanicDamage() {}
}
