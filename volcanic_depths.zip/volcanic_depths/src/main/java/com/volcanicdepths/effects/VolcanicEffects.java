package com.volcanicdepths.effects;

import com.volcanicdepths.block.SmokingVentBlock;
import com.volcanicdepths.block.SuperheatedMagmaBlock;
import com.volcanicdepths.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;

/**
 * Client-side visuals for the volcanic blocks. Only ever called from animateTick / block events on the logical
 * client, and it only uses Level#addParticle (which already honours the player's particle setting), so it is
 * safe to reference from common block classes. Counts are deliberately small.
 */
public final class VolcanicEffects {
    private static void add(Level l, ParticleOptions o, double x, double y, double z, double vx, double vy, double vz) {
        l.addParticle(o, x, y, z, vx, vy, vz);
    }

    private static double j(RandomSource r, double spread) {
        return (r.nextDouble() - 0.5) * spread;
    }

    private static boolean covered(Level level, BlockPos above) {
        return level.getBlockState(above).isCollisionShapeFullBlock(level, above);
    }

    // ------------------------------------------------------------------------------------------ scalding rock
    public static void scaldingRockAmbient(Level level, BlockPos pos, RandomSource r) {
        BlockPos above = pos.above();
        if (covered(level, above)) {
            // Ceiling / wall crack: a thin wisp that creeps out along the underside.
            BlockPos below = pos.below();
            if (level.getBlockState(below).isAir() && r.nextInt(16) == 0) {
                add(level, ModParticles.SMOKE.get(), pos.getX() + r.nextDouble(), pos.getY() - 0.1, pos.getZ() + r.nextDouble(),
                        j(r, 0.02), -0.005, j(r, 0.02));
            }
            return;
        }
        double x = pos.getX() + 0.2 + r.nextDouble() * 0.6, y = pos.getY() + 1.0, z = pos.getZ() + 0.2 + r.nextDouble() * 0.6;
        if (r.nextInt(9) == 0) add(level, ModParticles.STEAM.get(), x, y, z, j(r, 0.01), 0.03 + r.nextDouble() * 0.02, j(r, 0.01));
        if (r.nextInt(36) == 0) add(level, ModParticles.EMBER.get(), x, y, z, j(r, 0.02), 0.03, j(r, 0.02));
    }

    // ------------------------------------------------------------------------------------------ superheated magma
    public static void magmaAmbient(Level level, BlockPos pos, SuperheatedMagmaBlock.Phase phase, RandomSource r) {
        BlockPos above = pos.above();
        if (covered(level, above)) return;
        double x = pos.getX() + 0.15 + r.nextDouble() * 0.7, y = pos.getY() + 1.0, z = pos.getZ() + 0.15 + r.nextDouble() * 0.7;
        switch (phase) {
            case DORMANT -> {
                if (r.nextInt(8) == 0) add(level, ModParticles.EMBER.get(), x, y, z, j(r, 0.02), 0.04, j(r, 0.02));
                if (r.nextInt(14) == 0) add(level, ModParticles.HAZE.get(), x, y + 0.2, z, 0.0, 0.04, 0.0);
                if (r.nextInt(30) == 0) add(level, ModParticles.SMOKE.get(), x, y, z, j(r, 0.01), 0.03, j(r, 0.01));
            }
            case RUMBLING -> {
                if (r.nextInt(3) == 0) add(level, ModParticles.EMBER.get(), x, y, z, j(r, 0.04), 0.06, j(r, 0.04));
                if (r.nextInt(5) == 0) add(level, ModParticles.SMOKE.get(), x, y, z, j(r, 0.02), 0.05, j(r, 0.02));
                if (r.nextInt(12) == 0) add(level, ParticleTypes.LAVA, x, y, z, 0, 0, 0);
            }
            case CHARGING -> {
                add(level, ModParticles.EMBER.get(), x, y, z, j(r, 0.08), 0.1 + r.nextDouble() * 0.1, j(r, 0.08));
                if (r.nextInt(2) == 0) add(level, ModParticles.STEAM.get(), x, y, z, j(r, 0.03), 0.07, j(r, 0.03));
                if (r.nextInt(5) == 0) add(level, ParticleTypes.LAVA, x, y, z, 0, 0, 0);
            }
            case COOLING -> {
                if (r.nextInt(10) == 0) add(level, ModParticles.STEAM.get(), x, y, z, j(r, 0.01), 0.03, j(r, 0.01));
            }
            default -> { }
        }
    }

    public static void magmaEvent(Level level, BlockPos pos, int id, int param) {
        RandomSource r = level.getRandom();
        double cx = pos.getX() + 0.5, cz = pos.getZ() + 0.5, top = pos.getY() + 1.0;
        switch (id) {
            case SuperheatedMagmaBlock.EVT_RUMBLE -> {
                for (int i = 0; i < 3; i++) add(level, ModParticles.SMOKE.get(), cx + j(r, 0.8), top, cz + j(r, 0.8), j(r, 0.02), 0.05, j(r, 0.02));
                for (int i = 0; i < 2; i++) add(level, ModParticles.EMBER.get(), cx + j(r, 0.8), top, cz + j(r, 0.8), j(r, 0.05), 0.08, j(r, 0.05));
            }
            case SuperheatedMagmaBlock.EVT_CHARGE -> {
                for (int i = 0; i < 5; i++) add(level, ModParticles.SMOKE.get(), cx + j(r, 0.9), top, cz + j(r, 0.9), j(r, 0.03), 0.07, j(r, 0.03));
                for (int i = 0; i < 6; i++) add(level, ModParticles.EMBER.get(), cx + j(r, 0.9), top, cz + j(r, 0.9), j(r, 0.1), 0.12, j(r, 0.1));
                for (int i = 0; i < 2; i++) add(level, ParticleTypes.LAVA, cx + j(r, 0.8), top, cz + j(r, 0.8), 0, 0, 0);
            }
            case SuperheatedMagmaBlock.EVT_ERUPT -> {
                int h = Math.max(1, param);
                for (int i = 0; i < 6; i++) add(level, ParticleTypes.FLAME, cx + j(r, 0.6), top + 0.1, cz + j(r, 0.6), j(r, 0.08), 0.35 + r.nextDouble() * 0.25, j(r, 0.08));
                for (int i = 0; i < 3; i++) add(level, ParticleTypes.LAVA, cx + j(r, 0.5), top + 0.3, cz + j(r, 0.5), 0, 0, 0);
                for (int i = 0; i < 5; i++) add(level, ModParticles.EMBER.get(), cx + j(r, 0.6), top + 0.2, cz + j(r, 0.6), j(r, 0.12), 0.25 + r.nextDouble() * 0.2, j(r, 0.12));
                for (int i = 0; i < 3; i++) add(level, ModParticles.SMOKE.get(), cx + j(r, 0.8), top + Math.min(h, 8) * (0.4 + r.nextDouble() * 0.6), cz + j(r, 0.8), j(r, 0.03), 0.08, j(r, 0.03));
                for (int i = 0; i < 2; i++) add(level, ModParticles.ASH.get(), cx + j(r, 3.0), top + h * (0.5 + r.nextDouble() * 0.5), cz + j(r, 3.0), j(r, 0.05), 0.02, j(r, 0.05));
                if (r.nextInt(3) == 0) add(level, ModParticles.STEAM.get(), cx + j(r, 1.0), top + 0.2, cz + j(r, 1.0), j(r, 0.06), 0.1, j(r, 0.06));
            }
            case SuperheatedMagmaBlock.EVT_COOL -> {
                for (int i = 0; i < 3; i++) add(level, ModParticles.STEAM.get(), cx + j(r, 0.8), top, cz + j(r, 0.8), j(r, 0.02), 0.05, j(r, 0.02));
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------------------------------ smoking vent
    public static void ventAmbient(Level level, BlockPos pos, boolean active, RandomSource r) {
        double x = pos.getX() + 0.35 + r.nextDouble() * 0.3, y = pos.getY() + 1.0, z = pos.getZ() + 0.35 + r.nextDouble() * 0.3;
        if (r.nextInt(active ? 2 : 6) == 0) add(level, ModParticles.SMOKE.get(), x, y, z, j(r, 0.01), 0.04 + r.nextDouble() * 0.03, j(r, 0.01));
        if (active && r.nextInt(3) == 0) add(level, ModParticles.EMBER.get(), x, y, z, j(r, 0.04), 0.08, j(r, 0.04));
        if (!active && r.nextInt(25) == 0) add(level, ModParticles.STEAM.get(), x, y, z, j(r, 0.01), 0.04, j(r, 0.01));
    }

    public static void ventEvent(Level level, BlockPos pos, int id, int param) {
        RandomSource r = level.getRandom();
        double cx = pos.getX() + 0.5, cz = pos.getZ() + 0.5, top = pos.getY() + 1.0;
        if (id == SmokingVentBlock.EVT_WARN) {
            for (int i = 0; i < 3; i++) add(level, ModParticles.SMOKE.get(), cx + j(r, 0.4), top, cz + j(r, 0.4), j(r, 0.02), 0.06, j(r, 0.02));
        } else if (id == SmokingVentBlock.EVT_BURST) {
            for (int i = 0; i < 6; i++) add(level, ModParticles.SMOKE.get(), cx + j(r, 0.5), top, cz + j(r, 0.5), j(r, 0.04), 0.12 + r.nextDouble() * 0.08, j(r, 0.04));
            for (int i = 0; i < 3; i++) add(level, ModParticles.STEAM.get(), cx + j(r, 0.5), top, cz + j(r, 0.5), j(r, 0.05), 0.1, j(r, 0.05));
            for (int i = 0; i < 5; i++) add(level, ModParticles.EMBER.get(), cx + j(r, 0.4), top, cz + j(r, 0.4), j(r, 0.08), 0.18 + r.nextDouble() * 0.1, j(r, 0.08));
            for (int i = 0; i < 2; i++) add(level, ParticleTypes.FLAME, cx + j(r, 0.3), top, cz + j(r, 0.3), j(r, 0.03), 0.2, j(r, 0.03));
        }
    }

    // ------------------------------------------------------------------------------------------ biome-wide
    public static void ashCloud(Level level, double x, double y, double z, RandomSource r) {
        for (int i = 0; i < 6; i++) {
            add(level, ModParticles.SMOKE.get(), x + j(r, 5.0), y + j(r, 2.5), z + j(r, 5.0), j(r, 0.01), 0.004, j(r, 0.01));
        }
        for (int i = 0; i < 4; i++) {
            add(level, ModParticles.ASH.get(), x + j(r, 6.0), y + j(r, 3.0), z + j(r, 6.0), j(r, 0.02), -0.01, j(r, 0.02));
        }
    }

    private VolcanicEffects() {}
}
