package com.volcanicdepths.worldgen;

import com.volcanicdepths.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Small world-generation helpers shared by the features. */
final class WG {
    /** Air or an ash layer: space a formation may build into. */
    static boolean free(BlockState s) {
        return s.isAir() || s.is(ModBlocks.ASH_LAYER.get());
    }

    static boolean solidAt(BlockGetter level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return s.getFluidState().isEmpty() && s.isCollisionShapeFullBlock(level, pos);
    }

    /** Things a chamber may carve through. */
    static boolean carvable(BlockState s) {
        return s.is(BlockTags.OVERWORLD_CARVER_REPLACEABLES)
                || s.is(ModBlocks.ASHEN_STONE.get()) || s.is(ModBlocks.SCALDING_ROCK.get());
    }

    static BlockState ashen() {
        return ModBlocks.ASHEN_STONE.get().defaultBlockState();
    }

    static BlockState scalding() {
        return ModBlocks.SCALDING_ROCK.get().defaultBlockState();
    }

    static BlockState ash(int layers) {
        return ModBlocks.ASH_LAYER.get().defaultBlockState().setValue(SnowLayerBlock.LAYERS, Mth.clamp(layers, 1, 8));
    }

    /** Ashen stone, with a heat-dependent chance of scalding rock. {@code mult} scales that chance. */
    static BlockState rock(RandomSource random, double heat, double mult) {
        double p = Mth.clamp((heat - VolcanicHeat.SCALD_MIN + 0.0) / 0.5, 0.0, 0.8) * mult;
        return random.nextDouble() < p ? scalding() : ashen();
    }

    private WG() {}
}
