package com.volcanicdepths.worldgen;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.volcanicdepths.registry.ModBlocks;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration;
import net.minecraft.world.level.material.Fluids;

/**
 * All of the hand-built volcanic formations, selected by the {@code kind} field of the configured feature:
 * lava_pool, lava_fall, pillar, chimney, vent, scalding_cluster, magma_formation, ash_mound, chamber.
 *
 * <p>Each formation first looks for a real cave floor/ceiling near the random origin (so nothing is placed in
 * solid rock or floating), checks the local {@link VolcanicHeat} so hot formations only appear in hot districts,
 * and then builds with tapered, noisy shapes rather than scattering blocks.
 */
public class VolcanicFormationFeature extends Feature<VolcanicFormationFeature.Config> {
    public record Config(String kind) implements FeatureConfiguration {
        public static final Codec<Config> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("kind").forGetter(Config::kind)).apply(i, Config::new));
    }

    private static final int SEARCH = 24;
    private static final Direction[] SEALING = {Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    public VolcanicFormationFeature(Codec<Config> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<Config> ctx) {
        WorldGenLevel level = ctx.level();
        BlockPos origin = ctx.origin();
        RandomSource random = ctx.random();
        return switch (ctx.config().kind()) {
            case "lava_pool" -> lavaPool(level, origin, random);
            case "lava_fall" -> lavaFall(level, origin, random, 0.45);
            case "pillar" -> pillar(level, origin, random);
            case "chimney" -> chimney(level, origin, random);
            case "vent" -> vent(level, origin, random);
            case "scalding_cluster" -> scaldingCluster(level, origin, random);
            case "magma_formation" -> magmaFormation(level, origin, random);
            case "ash_mound" -> ashMound(level, origin, random);
            case "chamber" -> chamber(level, origin, random);
            default -> false;
        };
    }

    // ----------------------------------------------------------------------------------------------- helpers
    private static boolean set(WorldGenLevel level, BlockPos pos, BlockState state) {
        return level.setBlock(pos, state, 2);
    }

    /** Returns the air block sitting on the nearest cave floor at or around {@code start}, or null. */
    private static BlockPos findFloor(WorldGenLevel level, BlockPos start) {
        BlockPos.MutableBlockPos p = start.mutable();
        int n = 0;
        while (!WG.free(level.getBlockState(p)) && n++ < SEARCH) {
            p.move(Direction.UP);
            if (level.isOutsideBuildHeight(p)) return null;
        }
        if (!WG.free(level.getBlockState(p))) return null;
        n = 0;
        while (WG.free(level.getBlockState(p.below())) && n++ < SEARCH) p.move(Direction.DOWN);
        if (level.isOutsideBuildHeight(p.below()) || !WG.solidAt(level, p.below())) return null;
        return p.immutable();
    }

    private static int clearance(WorldGenLevel level, BlockPos floorAir, int max) {
        int c = 0;
        BlockPos.MutableBlockPos m = floorAir.mutable();
        while (c < max && WG.free(level.getBlockState(m))) {
            c++;
            m.move(Direction.UP);
        }
        return c;
    }

    private static void clearAsh(WorldGenLevel level, BlockPos pos) {
        if (level.getBlockState(pos).is(ModBlocks.ASH_LAYER.get())) set(level, pos, Blocks.AIR.defaultBlockState());
    }

    /** Extends a column downward from {@code pos} until it meets solid ground (max 4), so bases are not floating. */
    private static void fillDown(WorldGenLevel level, BlockPos pos, RandomSource random, double heat) {
        BlockPos.MutableBlockPos m = pos.below().mutable();
        for (int i = 0; i < 4 && WG.free(level.getBlockState(m)); i++) {
            set(level, m, WG.rock(random, heat, 0.3));
            m.move(Direction.DOWN);
        }
    }

    // ----------------------------------------------------------------------------------------------- lava pool
    private boolean lavaPool(WorldGenLevel level, BlockPos origin, RandomSource random) {
        BlockPos c = findFloor(level, origin);
        if (c == null) return false;
        double heat = VolcanicHeat.heatAt(level, c);
        if (heat < 0.32) return false;

        int r = 2 + random.nextInt(3) + (heat > 0.6 ? 1 : 0);
        Set<BlockPos> cells = new HashSet<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (Math.sqrt(dx * dx + dz * dz) > r * (0.65 + random.nextDouble() * 0.5)) continue;
                BlockPos pos = c.offset(dx, 0, dz);
                if (WG.free(level.getBlockState(pos)) && WG.solidAt(level, pos.below()) && WG.solidAt(level, pos.below(2))) {
                    cells.add(pos);
                }
            }
        }
        // Prune until the pool is fully enclosed: every neighbour is pool or has a solid floor-level block.
        boolean changed = true;
        for (int guard = 0; changed && guard < 8; guard++) {
            changed = false;
            Iterator<BlockPos> it = cells.iterator();
            while (it.hasNext()) {
                BlockPos pos = it.next();
                for (Direction d : Direction.Plane.HORIZONTAL) {
                    BlockPos n = pos.relative(d);
                    if (!cells.contains(n) && !WG.solidAt(level, n.below())) {
                        it.remove();
                        changed = true;
                        break;
                    }
                }
            }
        }
        if (cells.size() < 4) return false;

        for (BlockPos pos : cells) {
            set(level, pos.below(), Blocks.LAVA.defaultBlockState());
            clearAsh(level, pos);
        }
        for (BlockPos pos : cells) {
            for (Direction d : Direction.Plane.HORIZONTAL) {
                BlockPos side = pos.relative(d);
                BlockPos rim = side.below();
                if (!cells.contains(side) && WG.solidAt(level, rim) && random.nextFloat() < 0.55F) {
                    set(level, rim, WG.rock(random, heat + 0.1, 1.0));
                }
            }
        }
        return true;
    }

    // ----------------------------------------------------------------------------------------------- lava fall
    private boolean lavaFall(WorldGenLevel level, BlockPos origin, RandomSource random, double minHeat) {
        BlockPos.MutableBlockPos p = origin.mutable();
        int n = 0;
        while (!WG.free(level.getBlockState(p)) && n++ < 12) p.move(Direction.UP);
        if (!WG.free(level.getBlockState(p))) return false;
        n = 0;
        while (WG.free(level.getBlockState(p.above())) && n++ < SEARCH) p.move(Direction.UP);

        BlockPos source = p.above();
        if (level.isOutsideBuildHeight(source) || !WG.solidAt(level, source)) return false;
        if (minHeat > 0 && VolcanicHeat.heatAt(level, p) < minHeat) return false;

        int drop = 0;
        BlockPos.MutableBlockPos q = p.mutable();
        while (WG.free(level.getBlockState(q)) && drop < 32) {
            q.move(Direction.DOWN);
            drop++;
        }
        if (drop < 5 || !WG.solidAt(level, q)) return false;
        for (Direction d : SEALING) { // the source must be sealed on every side except downward
            if (!WG.solidAt(level, source.relative(d))) return false;
        }
        set(level, source, Blocks.LAVA.defaultBlockState());
        level.scheduleTick(source, Fluids.LAVA, 30); // kick the fluid so it starts to fall
        for (Direction d : Direction.Plane.HORIZONTAL) set(level, source.relative(d), WG.scalding());
        return true;
    }

    // ----------------------------------------------------------------------------------------------- pillars
    private boolean pillar(WorldGenLevel level, BlockPos origin, RandomSource random) {
        BlockPos base = findFloor(level, origin);
        if (base == null) return false;
        double heat = VolcanicHeat.heatAt(level, base);
        if (heat < 0.2) return false;
        return buildPillar(level, base, random, heat);
    }

    private boolean buildPillar(WorldGenLevel level, BlockPos base, RandomSource random, double heat) {
        int clear = clearance(level, base, 30);
        if (clear < 4) return false;
        double baseR = 1.4 + random.nextDouble() * 2.0 + heat * 0.6;
        int height = 4 + random.nextInt(10);
        boolean joins = height >= clear - 1;
        if (joins) height = clear;

        for (int h = 0; h < height; h++) {
            double t = h / (double) height;
            double r = joins ? baseR * (0.45 + 0.9 * Math.abs(t - 0.5)) : baseR * (1.0 - 0.7 * t);
            r += (random.nextDouble() - 0.5) * 0.7;
            r = Math.max(r, h < height - 1 ? 0.8 : 0.5);
            int ir = (int) Math.ceil(r);
            for (int dx = -ir; dx <= ir; dx++) {
                for (int dz = -ir; dz <= ir; dz++) {
                    if (dx * dx + dz * dz > r * r) continue;
                    BlockPos pos = base.offset(dx, h, dz);
                    if (!WG.free(level.getBlockState(pos))) continue;
                    set(level, pos, WG.rock(random, heat, h == 0 ? 0.3 : 0.8));
                    if (h == 0) fillDown(level, pos, random, heat);
                }
            }
        }
        if (!joins) { // jagged tip
            for (int i = 0; i < random.nextInt(3); i++) {
                BlockPos tip = base.above(height + i);
                if (WG.free(level.getBlockState(tip))) set(level, tip, WG.rock(random, heat, 1.0));
            }
        }
        return true;
    }

    // ----------------------------------------------------------------------------------------------- chimney
    private boolean chimney(WorldGenLevel level, BlockPos origin, RandomSource random) {
        BlockPos base = findFloor(level, origin);
        if (base == null) return false;
        double heat = VolcanicHeat.heatAt(level, base);
        if (heat < 0.42) return false;
        int clear = clearance(level, base, 20);
        if (clear < 7) return false;
        int height = Math.min(5 + random.nextInt(5), clear - 2);

        for (int h = 0; h < height; h++) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dz == 0) continue; // the shaft stays open
                    if (h > height - 3 && random.nextFloat() < 0.18F * (h - (height - 3)) + 0.1F) continue; // broken rim
                    if (Math.abs(dx) == 1 && Math.abs(dz) == 1 && h > height / 2 && random.nextFloat() < 0.5F) continue;
                    BlockPos pos = base.offset(dx, h, dz);
                    if (!WG.free(level.getBlockState(pos))) continue;
                    set(level, pos, WG.rock(random, heat, 0.6));
                    if (h == 0) fillDown(level, pos, random, heat);
                }
            }
        }
        for (int dx = -2; dx <= 2; dx++) { // rubble skirt
            for (int dz = -2; dz <= 2; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) != 2 || random.nextFloat() > 0.55F) continue;
                BlockPos pos = base.offset(dx, 0, dz);
                if (WG.free(level.getBlockState(pos)) && WG.solidAt(level, pos.below())) {
                    set(level, pos, WG.rock(random, heat, 0.4));
                }
            }
        }
        set(level, base.below(), ModBlocks.SMOKING_VENT.get().defaultBlockState());
        clearAsh(level, base);
        return true;
    }

    // ----------------------------------------------------------------------------------------------- magma vent
    private boolean vent(WorldGenLevel level, BlockPos origin, RandomSource random) {
        BlockPos base = findFloor(level, origin);
        if (base == null) return false;
        double heat = VolcanicHeat.heatAt(level, base);
        if (heat < 0.4) return false;
        int r = 2 + random.nextInt(2);
        List<BlockPos> inner = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int d2 = dx * dx + dz * dz;
                if (d2 > r * r + 1) continue;
                BlockPos pos = base.offset(dx, 0, dz);
                BlockPos floor = pos.below();
                if (!WG.free(level.getBlockState(pos)) || !WG.solidAt(level, floor)) continue;
                boolean core = d2 <= 2;
                set(level, floor, (core || random.nextFloat() < 0.5F) ? WG.scalding() : WG.ashen());
                clearAsh(level, pos);
                if (core) inner.add(floor);
            }
        }
        if (inner.isEmpty()) return false;
        Collections.shuffle(inner, new Random(random.nextLong()));
        int vents = 1 + random.nextInt(2) + (heat > 0.65 ? 1 : 0);
        for (int i = 0; i < Math.min(vents, inner.size()); i++) {
            set(level, inner.get(i), ModBlocks.SMOKING_VENT.get().defaultBlockState());
        }
        return true;
    }

    // ----------------------------------------------------------------------------------------------- scalding cluster
    private boolean scaldingCluster(WorldGenLevel level, BlockPos origin, RandomSource random) {
        BlockPos base = findFloor(level, origin);
        if (base == null) return false;
        double heat = VolcanicHeat.heatAt(level, base);
        if (heat < 0.33) return false;
        int r = 2 + random.nextInt(3);
        int maxH = 2 + random.nextInt(3);
        boolean any = false;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > r) continue;
                BlockPos pos = base.offset(dx, 0, dz);
                if (!WG.free(level.getBlockState(pos)) || !WG.solidAt(level, pos.below())) continue;
                int h = (int) Math.round((1 - d / r) * maxH * (0.5 + random.nextDouble() * 0.7));
                if (h == 0 && random.nextFloat() < 0.35F) set(level, pos.below(), WG.scalding());
                for (int k = 0; k < h; k++) {
                    BlockPos p = pos.above(k);
                    if (!WG.free(level.getBlockState(p))) break;
                    set(level, p, (k == h - 1 || random.nextBoolean()) ? WG.scalding() : WG.ashen());
                    any = true;
                }
            }
        }
        return any;
    }

    // ----------------------------------------------------------------------------------------------- magma formation
    private boolean magmaFormation(WorldGenLevel level, BlockPos origin, RandomSource random) {
        BlockPos base = findFloor(level, origin);
        if (base == null) return false;
        double heat = VolcanicHeat.heatAt(level, base);
        if (heat < 0.68 || clearance(level, base, 8) < 5) return false;

        BlockState magma = ModBlocks.SUPERHEATED_MAGMA.get().defaultBlockState();
        int R = 3 + random.nextInt(3) + (heat > 0.85 ? 1 : 0);
        int pads = 0;
        for (int dx = -R - 1; dx <= R + 1; dx++) {
            for (int dz = -R - 1; dz <= R + 1; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > R * (0.8 + random.nextDouble() * 0.4)) continue;
                BlockPos pos = base.offset(dx, 0, dz);
                BlockPos floor = pos.below();
                if (!WG.free(level.getBlockState(pos)) || !WG.solidAt(level, floor)) continue;
                double nd = d / R;
                clearAsh(level, pos);
                if (nd < 0.45) {
                    if (random.nextFloat() < 0.75F) {
                        set(level, floor, magma);
                        pads++;
                        if (nd < 0.2 && random.nextFloat() < 0.4F) set(level, pos, magma); // raised core
                    } else {
                        set(level, floor, WG.scalding());
                    }
                } else if (nd < 0.8) {
                    set(level, floor, random.nextFloat() < 0.7F ? WG.scalding() : WG.ashen());
                    if (random.nextFloat() < 0.25F) set(level, pos, WG.ashen());
                } else {
                    set(level, floor, WG.ashen());
                    if (random.nextFloat() < 0.35F) set(level, pos, WG.ashen());
                }
            }
        }
        return pads > 0;
    }

    // ----------------------------------------------------------------------------------------------- ash mound
    private boolean ashMound(WorldGenLevel level, BlockPos origin, RandomSource random) {
        BlockPos base = findFloor(level, origin);
        if (base == null) return false;
        double heat = VolcanicHeat.heatAt(level, base);
        if (heat < 0.03 || heat > 0.65) return false;
        int r = 2 + random.nextInt(3);
        int maxUnits = 8 + random.nextInt(10); // 8 units = one full block
        boolean any = false;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > r) continue;
                BlockPos pos = base.offset(dx, 0, dz);
                if (!WG.free(level.getBlockState(pos)) || !WG.solidAt(level, pos.below())) continue;
                double f = 1 - d / (r + 0.5);
                int units = (int) Math.round(maxUnits * f * f * (0.7 + 0.5 * random.nextDouble()));
                if (units <= 0) continue;
                int full = units / 8, rem = units % 8;
                for (int k = 0; k < full; k++) {
                    BlockPos p = pos.above(k);
                    if (WG.free(level.getBlockState(p))) set(level, p, WG.ash(8));
                }
                if (rem > 0) {
                    BlockPos p = pos.above(full);
                    if (WG.free(level.getBlockState(p))) set(level, p, WG.ash(rem));
                }
                any = true;
            }
        }
        return any;
    }

    // ----------------------------------------------------------------------------------------------- chamber
    /**
     * A large, rare volcanic chamber: a noisy ellipsoid cavern with a lava lake in its bowl, a raised ring
     * terrace of scalding/ashen rock around the lake, several superheated-magma geyser pads on that terrace,
     * jagged pillars, and lava falls from the ceiling. Aborts if it would touch water or break near the surface.
     */
    private boolean chamber(WorldGenLevel level, BlockPos origin, RandomSource random) {
        double heat = VolcanicHeat.heatAt(level, origin);
        if (heat < 0.7) return false;
        int rx = 8 + random.nextInt(5), rz = 8 + random.nextInt(5), ry = 5 + random.nextInt(4);
        int minY = level.getMinBuildHeight();
        int cy = Mth.clamp(origin.getY(), minY + ry + 8, 20);
        BlockPos c = new BlockPos(origin.getX(), cy, origin.getZ());
        int surface = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, c.getX(), c.getZ());
        if (surface - (cy + ry) < 8) return false;
        long seed = level.getSeed();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();

        for (int dx = -rx - 1; dx <= rx + 1; dx++) {
            for (int dy = -ry - 1; dy <= ry + 1; dy++) {
                for (int dz = -rz - 1; dz <= rz + 1; dz++) {
                    m.set(c.getX() + dx, cy + dy, c.getZ() + dz);
                    if (level.getFluidState(m).is(FluidTags.WATER)) return false;
                }
            }
        }

        // 1. the carved volume
        Set<BlockPos> carve = new HashSet<>();
        for (int dx = -rx; dx <= rx; dx++) {
            for (int dy = -ry; dy <= ry; dy++) {
                for (int dz = -rz; dz <= rz; dz++) {
                    double nx = dx / (double) rx, ny = dy / (double) ry, nz = dz / (double) rz;
                    double wob = VolcanicHeat.shape(seed, c.getX() + dx, cy + dy, c.getZ() + dz) * 0.45;
                    if (nx * nx + ny * ny + nz * nz + wob > 1.0) continue;
                    m.set(c.getX() + dx, cy + dy, c.getZ() + dz);
                    BlockState s = level.getBlockState(m);
                    if (s.isAir() || WG.carvable(s)) carve.add(m.immutable());
                }
            }
        }
        if (carve.size() < 200) return false;

        // 2. lava lake in the bowl, terrace ring around it
        int lakeY = cy - (int) (ry * 0.5);
        int terraceTop = lakeY + 2;
        Set<BlockPos> lava = new HashSet<>();
        List<BlockPos> terrace = new ArrayList<>();
        for (BlockPos p : carve) {
            double hn = Math.sqrt(Math.pow((p.getX() - c.getX()) / (double) rx, 2) + Math.pow((p.getZ() - c.getZ()) / (double) rz, 2));
            if (hn >= 0.6 && p.getY() <= terraceTop) {
                set(level, p, WG.rock(random, 0.95, 0.6));
                if (p.getY() == terraceTop) terrace.add(p);
            } else if (p.getY() <= lakeY) {
                set(level, p, Blocks.LAVA.defaultBlockState());
                lava.add(p);
            } else {
                set(level, p, Blocks.AIR.defaultBlockState());
            }
        }
        for (BlockPos p : lava) { // seal any cave the bowl happened to cut into
            for (Direction d : new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
                BlockPos n = p.relative(d);
                if (!lava.contains(n) && !carve.contains(n) && !WG.solidAt(level, n)) set(level, n, WG.scalding());
            }
        }

        // 3. re-skin the shell of the chamber
        Set<BlockPos> done = new HashSet<>();
        for (BlockPos p : carve) {
            for (Direction d : Direction.values()) {
                BlockPos n = p.relative(d);
                if (carve.contains(n) || !done.add(n)) continue;
                if (WG.carvable(level.getBlockState(n))) set(level, n, WG.rock(random, 0.95, 0.6));
            }
        }

        // 4. geyser pads on the terrace
        Collections.shuffle(terrace, new Random(random.nextLong()));
        List<BlockPos> chosen = new ArrayList<>();
        int wanted = 4 + random.nextInt(5);
        BlockState magma = ModBlocks.SUPERHEATED_MAGMA.get().defaultBlockState();
        for (BlockPos p : terrace) {
            if (chosen.size() >= wanted) break;
            if (!WG.free(level.getBlockState(p.above())) || !WG.free(level.getBlockState(p.above(2)))) continue;
            boolean spaced = true;
            for (BlockPos o : chosen) {
                if (Math.abs(o.getX() - p.getX()) + Math.abs(o.getZ() - p.getZ()) < 4) {
                    spaced = false;
                    break;
                }
            }
            if (!spaced) continue;
            chosen.add(p);
            set(level, p, magma);
            for (Direction d : Direction.Plane.HORIZONTAL) {
                BlockPos n = p.relative(d);
                if (terrace.contains(n) && random.nextFloat() < 0.4F) set(level, n, magma);
            }
        }

        // 5. pillars and lava falls
        int pillars = 2 + random.nextInt(2);
        for (BlockPos p : terrace) {
            if (pillars <= 0) break;
            if (random.nextInt(6) != 0 || chosen.contains(p) || !WG.free(level.getBlockState(p.above()))) continue;
            if (buildPillar(level, p.above(), random, 0.9)) pillars--;
        }
        for (int i = 0; i < 3; i++) {
            BlockPos q = new BlockPos(c.getX() + (int) ((random.nextDouble() - 0.5) * rx), terraceTop + 3, c.getZ() + (int) ((random.nextDouble() - 0.5) * rz));
            if (lavaFall(level, q, random, 0.0) && random.nextBoolean()) break;
        }
        return true;
    }
}
