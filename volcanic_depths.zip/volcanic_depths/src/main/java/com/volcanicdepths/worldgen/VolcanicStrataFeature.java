package com.volcanicdepths.worldgen;

import com.mojang.serialization.Codec;
import com.volcanicdepths.registry.ModBiomes;
import com.volcanicdepths.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Chunk-wide terrain pass. Runs once for every chunk that touches the biome and re-skins the walls, floors and
 * ceilings of the caves that vanilla already carved ("integrates with cave generation"):
 *
 * <ol>
 *   <li>Samples the biome on a 4-block grid (plus an 8-block pad) to know where the biome is and how close to
 *       its border each spot is (the fade-in).</li>
 *   <li>Computes how far every stone block is from open space (0..3) so only the visible shell is touched.</li>
 *   <li>Converts that shell to Ashen Stone, then patches of Scalding Rock as {@link VolcanicHeat#heat} rises.</li>
 *   <li>Lays ash piles on calm floors.</li>
 * </ol>
 * It only writes inside its own chunk, so it never trips the world-gen write-radius limit.
 */
public class VolcanicStrataFeature extends Feature<NoneFeatureConfiguration> {
    private static final int PAD = 2;       // 4-block cells of padding around the chunk
    private static final int GRID = 4 + 2 * PAD;
    private static final int W = 22;        // distance grid width: chunk + 3 blocks each side
    private static final int WPAD = 3;

    public VolcanicStrataFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        RandomSource random = ctx.random();
        int x0 = ctx.origin().getX() & ~15;
        int z0 = ctx.origin().getZ() & ~15;
        int minY = level.getMinBuildHeight();
        int cellsY = (level.getMaxBuildHeight() - minY) >> 2;
        long seed = level.getSeed();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();

        // 1. biome grid -------------------------------------------------------------------------------------
        boolean[] vol = new boolean[GRID * GRID * cellsY];
        int loCy = Integer.MAX_VALUE, hiCy = -1;
        for (int cy = 0; cy < cellsY; cy++) {
            for (int cz = 0; cz < GRID; cz++) {
                for (int cx = 0; cx < GRID; cx++) {
                    m.set(x0 + (cx - PAD) * 4 + 2, minY + cy * 4 + 2, z0 + (cz - PAD) * 4 + 2);
                    boolean v = level.getBiome(m).is(ModBiomes.VOLCANIC_DEPTHS);
                    vol[(cy * GRID + cz) * GRID + cx] = v;
                    if (v && cx >= PAD && cx < PAD + 4 && cz >= PAD && cz < PAD + 4) {
                        loCy = Math.min(loCy, cy);
                        hiCy = Math.max(hiCy, cy);
                    }
                }
            }
        }
        if (hiCy < 0) return false;

        float[] edge = new float[16 * cellsY];
        for (int cy = loCy; cy <= hiCy; cy++) {
            for (int cz = 0; cz < 4; cz++) {
                for (int cx = 0; cx < 4; cx++) {
                    if (!vol[(cy * GRID + cz + PAD) * GRID + cx + PAD]) continue;
                    int n = 0;
                    for (int dz = -2; dz <= 2; dz++) {
                        for (int dx = -2; dx <= 2; dx++) {
                            if (vol[(cy * GRID + cz + PAD + dz) * GRID + cx + PAD + dx]) n++;
                        }
                    }
                    edge[(cy * 4 + cz) * 4 + cx] = (float) Mth.clamp((n / 25.0 - 0.35) / 0.6, 0.0, 1.0);
                }
            }
        }

        // 2. distance-to-open-space grid ----------------------------------------------------------------------
        int yLo = Math.max(minY, minY + loCy * 4 - 3);
        int yHi = Math.min(level.getMaxBuildHeight() - 1, minY + (hiCy + 1) * 4 + 2);
        int h = yHi - yLo + 1;
        int ox = x0 - WPAD, oz = z0 - WPAD;
        byte[] dist = new byte[W * W * h];
        for (int yy = 0; yy < h; yy++) {
            for (int zz = 0; zz < W; zz++) {
                for (int xx = 0; xx < W; xx++) {
                    m.set(ox + xx, yLo + yy, oz + zz);
                    BlockState s = level.getBlockState(m);
                    boolean solid = s.getFluidState().isEmpty() && s.isCollisionShapeFullBlock(level, m);
                    dist[(yy * W + zz) * W + xx] = (byte) (solid ? 4 : 0);
                }
            }
        }
        for (int pass = 0; pass < 3; pass++) {
            byte[] next = dist.clone();
            for (int yy = 0; yy < h; yy++) {
                for (int zz = 0; zz < W; zz++) {
                    for (int xx = 0; xx < W; xx++) {
                        int i = (yy * W + zz) * W + xx;
                        if (dist[i] == 0) continue;
                        int best = dist[i];
                        if (xx > 0) best = Math.min(best, dist[i - 1] + 1);
                        if (xx < W - 1) best = Math.min(best, dist[i + 1] + 1);
                        if (zz > 0) best = Math.min(best, dist[i - W] + 1);
                        if (zz < W - 1) best = Math.min(best, dist[i + W] + 1);
                        if (yy > 0) best = Math.min(best, dist[i - W * W] + 1);
                        if (yy < h - 1) best = Math.min(best, dist[i + W * W] + 1);
                        next[i] = (byte) best;
                    }
                }
            }
            dist = next;
        }

        // 3. convert the visible rock shell ------------------------------------------------------------------
        for (int lz = 0; lz < 16; lz++) {
            for (int lx = 0; lx < 16; lx++) {
                int x = x0 + lx, z = z0 + lz;
                for (int y = yLo; y <= yHi; y++) {
                    int cy = (y - minY) >> 2;
                    if (cy < loCy || cy > hiCy) continue;
                    float e = edge[(cy * 4 + (lz >> 2)) * 4 + (lx >> 2)];
                    if (e <= 0.02F) continue;
                    int d = dist[((y - yLo) * W + (lz + WPAD)) * W + (lx + WPAD)];
                    if (d < 1 || d > 3) continue;
                    m.set(x, y, z);
                    if (!level.getBlockState(m).is(BlockTags.BASE_STONE_OVERWORLD)) continue;
                    double heat = VolcanicHeat.heat(e, seed, x, y, z);
                    BlockState out = convert(level, m, d, heat, random, seed);
                    if (out != null) level.setBlock(m, out, 2);
                }
            }
        }

        // 4. ash on calm floors -------------------------------------------------------------------------------
        for (int lz = 0; lz < 16; lz++) {
            for (int lx = 0; lx < 16; lx++) {
                int x = x0 + lx, z = z0 + lz;
                for (int y = yHi; y > yLo; y--) {
                    int cy = (y - minY) >> 2;
                    if (cy < loCy || cy > hiCy) continue;
                    float e = edge[(cy * 4 + (lz >> 2)) * 4 + (lx >> 2)];
                    if (e <= 0.02F) continue;
                    m.set(x, y, z);
                    if (!level.getBlockState(m).isAir()) continue;
                    BlockPos below = m.below();
                    BlockState bs = level.getBlockState(below);
                    if (!bs.getFluidState().isEmpty() || !bs.isFaceSturdy(level, below, Direction.UP)) continue;
                    double heat = VolcanicHeat.heat(e, seed, x, y, z);
                    if (heat < 0.06 || heat > 0.62) continue;
                    double n = VolcanicHeat.patch(seed, x, y, z);
                    double thresh = 0.50 + heat * 0.4;
                    if (n <= thresh) continue;
                    int layers = 1 + (int) ((n - thresh) * 10.0) + random.nextInt(2);
                    level.setBlock(m, WG.ash(Math.min(layers, 5)), 2);
                }
            }
        }
        return true;
    }

    private static BlockState convert(WorldGenLevel level, BlockPos pos, int dist, double heat, RandomSource random, long seed) {
        if (heat < VolcanicHeat.ASH_MIN) return null;
        double ashP = (dist == 1 ? 0.97 : dist == 2 ? 0.70 : 0.40) * Mth.clamp((heat - VolcanicHeat.ASH_MIN) / 0.08, 0.0, 1.0);
        if (random.nextDouble() >= ashP) return null;

        boolean floor = WG.free(level.getBlockState(pos.above()));
        if (heat > VolcanicHeat.SCALD_MIN && dist <= 2) {
            double t = Mth.clamp((heat - VolcanicHeat.SCALD_MIN) / 0.45, 0.0, 1.0);
            double patch = VolcanicHeat.patch(seed, pos.getX(), pos.getY(), pos.getZ());
            double p = t * (0.3 + 0.9 * patch) * (dist == 1 ? 1.0 : 0.35);
            if (floor) p *= 0.6; // keep walking surfaces a little kinder than walls and ceilings
            if (random.nextDouble() < p) return ModBlocks.SCALDING_ROCK.get().defaultBlockState();
        }
        if (heat > 0.8 && dist == 1 && floor && random.nextFloat() < 0.01F) {
            return ModBlocks.SUPERHEATED_MAGMA.get().defaultBlockState();
        }
        return WG.ashen();
    }
}
