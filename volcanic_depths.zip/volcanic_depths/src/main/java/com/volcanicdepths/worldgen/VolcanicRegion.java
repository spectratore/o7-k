package com.volcanicdepths.worldgen;

import com.mojang.datafixers.util.Pair;
import com.volcanicdepths.registry.ModBiomes;
import java.util.function.Consumer;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Climate;
import terrablender.api.Region;
import terrablender.api.RegionType;

/**
 * Places the Volcanic Depths in the overworld climate map through TerraBlender.
 *
 * <p>The region keeps every vanilla biome untouched and only adds one extra underground point: deep (depth
 * parameter 0.55..1.0, i.e. well below the cave-biome layer), inland, fairly dry, with a limited weirdness band so
 * it forms patches instead of replacing the entire underground. The parameter box deliberately stops short of
 * dripstone caves (continentalness above 0.8) and lush caves (humidity above 0.7) so it never ties with them.
 *
 * <p>Frequency knobs: {@link #REGION_WEIGHT} (share of the world that uses this region; vanilla is 10) and the
 * parameter spans below (wider spans = bigger / more frequent patches).
 */
public class VolcanicRegion extends Region {
    public static final int REGION_WEIGHT = 8;

    public VolcanicRegion(ResourceLocation name, int weight) {
        super(name, RegionType.OVERWORLD, weight);
    }

    @Override
    public void addBiomes(Registry<Biome> registry, Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> mapper) {
        // Keep vanilla surface and cave biomes exactly as they are.
        addModifiedVanillaOverworldBiomes(mapper, builder -> { });

        mapper.accept(Pair.of(Climate.parameters(
                Climate.Parameter.span(-1.0F, 1.0F),     // temperature: any
                Climate.Parameter.span(-1.0F, 0.4F),     // humidity: not the lush-cave range
                Climate.Parameter.span(-0.1F, 0.8F),     // continentalness: inland, below the dripstone range
                Climate.Parameter.span(-1.0F, 1.0F),     // erosion: any
                Climate.Parameter.span(0.55F, 1.0F),     // depth: deep underground
                Climate.Parameter.span(-0.4F, 0.4F),     // weirdness: limits it to patches
                0.0F), ModBiomes.VOLCANIC_DEPTHS));
    }
}
