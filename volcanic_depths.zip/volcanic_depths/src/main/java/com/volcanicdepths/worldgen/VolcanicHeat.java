package com.volcanicdepths.worldgen;

import com.volcanicdepths.registry.ModBiomes;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.synth.ImprovedNoise;

/**
 * The "intensity" field that drives the whole progression
 * (normal cave -> ashen stone -> scalding rock -> lava -> superheated magma -> chambers).
 *
 * <pre>heat = edge * ( zone^1.5 * 1.15 + depthBonus * 0.6 )      clamped to 0..1</pre>
 * <ul>
 *   <li><b>edge</b> ramps from 0 at the border of the biome to 1 about 8 blocks inside, so the biome fades in.</li>
 *   <li><b>zone</b> is low-frequency 3D noise: broad calm ash caves versus hot volcanic districts.</li>
 *   <li><b>depthBonus</b> makes the lowest levels hotter.</li>
 * </ul>
 * Thresholds below are the tuning knobs for how much of the biome is calm vs dangerous.
 */
public final class VolcanicHeat {
    public static final double ASH_MIN = 0.10;
    public static final double SCALD_MIN = 0.38;

    private static final Map<Long, ImprovedNoise[]> NOISES = new ConcurrentHashMap<>();

    private static ImprovedNoise[] noises(long seed) {
        return NOISES.computeIfAbsent(seed, s -> {
            RandomSource r = RandomSource.create(s ^ 0x7A11CA0DEL);
            return new ImprovedNoise[]{new ImprovedNoise(r), new ImprovedNoise(r), new ImprovedNoise(r), new ImprovedNoise(r)};
        });
    }

    public static double zone(long seed, double x, double y, double z) {
        ImprovedNoise[] n = noises(seed);
        double v = n[0].noise(x / 42.0, y / 28.0, z / 42.0) * 0.65 + n[1].noise(x / 18.0, y / 12.0, z / 18.0) * 0.35;
        return Mth.clamp(0.5 + v * 1.1, 0.0, 1.0);
    }

    public static double depthBonus(int y) {
        return Mth.clamp((-10 - y) / 160.0, 0.0, 0.3);
    }

    public static double heat(double edge, long seed, int x, int y, int z) {
        double h = Math.pow(zone(seed, x, y, z), 1.5) * 1.15 + depthBonus(y) * 0.6;
        return Mth.clamp(edge * h, 0.0, 1.0);
    }

    /** Smooth 0..1 blob noise used to cluster scalding rock and ash. */
    public static double patch(long seed, int x, int y, int z) {
        return Mth.clamp(0.5 + 0.5 * noises(seed)[2].noise(x / 4.5, y / 4.5, z / 4.5) * 1.3, 0.0, 1.0);
    }

    /** Raw noise in about -0.7..0.7, for wobbling chamber walls. */
    public static double shape(long seed, int x, int y, int z) {
        return noises(seed)[3].noise(x / 5.5, y / 5.5, z / 5.5);
    }

    /** Fraction of a 5x5 ring (4 block spacing) around pos that is inside the biome, remapped to 0..1. */
    public static double edgeAt(WorldGenLevel level, BlockPos pos) {
        int inside = 0;
        for (int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                if (level.getBiome(pos.offset(i * 4, 0, j * 4)).is(ModBiomes.VOLCANIC_DEPTHS)) inside++;
            }
        }
        return Mth.clamp((inside / 25.0 - 0.35) / 0.6, 0.0, 1.0);
    }

    public static double heatAt(WorldGenLevel level, BlockPos pos) {
        double edge = edgeAt(level, pos);
        if (edge <= 0.0) return 0.0;
        return heat(edge, level.getSeed(), pos.getX(), pos.getY(), pos.getZ());
    }

    private VolcanicHeat() {}
}
