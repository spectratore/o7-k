package com.volcanicdepths;

import com.volcanicdepths.registry.ModBlocks;
import com.volcanicdepths.registry.ModEntities;
import com.volcanicdepths.registry.ModFeatures;
import com.volcanicdepths.registry.ModItems;
import com.volcanicdepths.registry.ModParticles;
import com.volcanicdepths.registry.ModSounds;
import com.volcanicdepths.worldgen.VolcanicRegion;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import terrablender.api.Regions;

@Mod(VolcanicDepths.MODID)
public class VolcanicDepths {
    public static final String MODID = "volcanic_depths";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }

    public VolcanicDepths(IEventBus modBus) {
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModItems.TABS.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        ModParticles.PARTICLES.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModFeatures.FEATURES.register(modBus);
        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        // TerraBlender injects the underground biome into the overworld climate parameter list.
        event.enqueueWork(() -> Regions.register(new VolcanicRegion(id("overworld"), VolcanicRegion.REGION_WEIGHT)));
    }
}
