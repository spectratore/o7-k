package com.volcanicdepths.registry;

import com.volcanicdepths.VolcanicDepths;
import com.volcanicdepths.worldgen.VolcanicFormationFeature;
import com.volcanicdepths.worldgen.VolcanicStrataFeature;
import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES =
            DeferredRegister.create(Registries.FEATURE, VolcanicDepths.MODID);

    public static final Supplier<VolcanicStrataFeature> STRATA = FEATURES.register("strata",
            () -> new VolcanicStrataFeature(NoneFeatureConfiguration.CODEC));
    public static final Supplier<VolcanicFormationFeature> FORMATION = FEATURES.register("formation",
            () -> new VolcanicFormationFeature(VolcanicFormationFeature.Config.CODEC));

    private ModFeatures() {}
}
