package com.volcanicdepths.registry;

import com.volcanicdepths.VolcanicDepths;
import com.volcanicdepths.block.AshLayerBlock;
import com.volcanicdepths.block.ScaldingRockBlock;
import com.volcanicdepths.block.SmokingVentBlock;
import com.volcanicdepths.block.SuperheatedMagmaBlock;
import java.util.function.Supplier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(VolcanicDepths.MODID);

    /** Main stone of the biome. Stone-tier pickaxe. */
    public static final DeferredBlock<Block> ASHEN_STONE = block("ashen_stone", () -> new Block(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).instrument(NoteBlockInstrument.BASEDRUM)
                    .requiresCorrectToolForDrops().strength(2.0F, 6.0F).sound(SoundType.STONE)));

    /** Hot rock with glowing cracks. Hurts anything standing on it. */
    public static final DeferredBlock<ScaldingRockBlock> SCALDING_ROCK = block("scalding_rock", () -> new ScaldingRockBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).instrument(NoteBlockInstrument.BASEDRUM)
                    .requiresCorrectToolForDrops().strength(3.0F, 8.0F).sound(SoundType.BASALT)
                    .lightLevel(s -> 5).emissiveRendering((s, l, p) -> true)));

    /** Rare geyser block. Iron-tier pickaxe. */
    public static final DeferredBlock<SuperheatedMagmaBlock> SUPERHEATED_MAGMA = block("superheated_magma", () -> new SuperheatedMagmaBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.NETHER).instrument(NoteBlockInstrument.BASEDRUM)
                    .requiresCorrectToolForDrops().strength(4.0F, 12.0F).sound(SoundType.STONE)
                    .lightLevel(SuperheatedMagmaBlock::lightFor).emissiveRendering((s, l, p) -> true)));

    /** Small fumarole used for chimneys and magma vents. */
    public static final DeferredBlock<SmokingVentBlock> SMOKING_VENT = block("smoking_vent", () -> new SmokingVentBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).instrument(NoteBlockInstrument.BASEDRUM)
                    .requiresCorrectToolForDrops().strength(3.0F, 8.0F).sound(SoundType.BASALT)
                    .lightLevel(s -> s.getValue(SmokingVentBlock.ACTIVE) ? 9 : 3)));

    /** Loose ash, layered like snow. Used for ash piles. */
    public static final DeferredBlock<AshLayerBlock> ASH_LAYER = block("ash_layer", () -> new AshLayerBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).replaceable().forceSolidOff()
                    .strength(0.2F).sound(SoundType.SAND).pushReaction(PushReaction.DESTROY)
                    .isViewBlocking((state, level, pos) -> state.getValue(SnowLayerBlock.LAYERS) >= 8)));

    private static <B extends Block> DeferredBlock<B> block(String name, Supplier<B> factory) {
        DeferredBlock<B> holder = BLOCKS.register(name, factory);
        ModItems.ITEMS.register(name, () -> new BlockItem(holder.get(), new Item.Properties()));
        return holder;
    }

    private ModBlocks() {}
}
