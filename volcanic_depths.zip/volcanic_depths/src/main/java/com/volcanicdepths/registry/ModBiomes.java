package com.volcanicdepths.registry;

import com.volcanicdepths.VolcanicDepths;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;

public final class ModBiomes {
    public static final ResourceKey<Biome> VOLCANIC_DEPTHS =
            ResourceKey.create(Registries.BIOME, VolcanicDepths.id("volcanic_depths"));

    private ModBiomes() {}
}
