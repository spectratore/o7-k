package com.volcanicdepths.registry;

import com.volcanicdepths.VolcanicDepths;
import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Sound events. Each is mapped to existing vanilla sounds in sounds.json (no tonal / beeping audio). */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, VolcanicDepths.MODID);

    public static final Supplier<SoundEvent> AMBIENT_RUMBLE = reg("ambient.rumble");
    public static final Supplier<SoundEvent> AMBIENT_MOOD = reg("ambient.mood");
    public static final Supplier<SoundEvent> MAGMA_RUMBLE = reg("magma.rumble");
    public static final Supplier<SoundEvent> MAGMA_CHARGE = reg("magma.charge");
    public static final Supplier<SoundEvent> GEYSER_ERUPT = reg("geyser.erupt");
    public static final Supplier<SoundEvent> GEYSER_HISS = reg("geyser.hiss");
    public static final Supplier<SoundEvent> VENT_WARN = reg("vent.warn");
    public static final Supplier<SoundEvent> VENT_BURST = reg("vent.burst");
    public static final Supplier<SoundEvent> DROPLET_SIZZLE = reg("droplet.sizzle");

    private static Supplier<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(VolcanicDepths.id(name)));
    }

    private ModSounds() {}
}
