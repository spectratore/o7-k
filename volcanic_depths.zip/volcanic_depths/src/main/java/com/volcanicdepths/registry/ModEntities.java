package com.volcanicdepths.registry;

import com.volcanicdepths.VolcanicDepths;
import com.volcanicdepths.entity.MagmaDroplet;
import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, VolcanicDepths.MODID);

    public static final Supplier<EntityType<MagmaDroplet>> MAGMA_DROPLET = ENTITIES.register("magma_droplet",
            () -> EntityType.Builder.<MagmaDroplet>of(MagmaDroplet::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(6).updateInterval(2).fireImmune().noSave()
                    .build("magma_droplet"));

    private ModEntities() {}
}
