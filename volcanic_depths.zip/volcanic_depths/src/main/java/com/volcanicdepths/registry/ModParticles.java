package com.volcanicdepths.registry;

import com.volcanicdepths.VolcanicDepths;
import java.util.function.Supplier;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(Registries.PARTICLE_TYPE, VolcanicDepths.MODID);

    public static final Supplier<SimpleParticleType> ASH = simple("ash");
    public static final Supplier<SimpleParticleType> EMBER = simple("ember");
    public static final Supplier<SimpleParticleType> STEAM = simple("steam");
    public static final Supplier<SimpleParticleType> SMOKE = simple("smoke");
    public static final Supplier<SimpleParticleType> HAZE = simple("haze");

    private static Supplier<SimpleParticleType> simple(String name) {
        return PARTICLES.register(name, () -> new SimpleParticleType(false));
    }

    private ModParticles() {}
}
