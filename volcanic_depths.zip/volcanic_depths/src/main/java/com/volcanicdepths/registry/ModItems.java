package com.volcanicdepths.registry;

import com.volcanicdepths.VolcanicDepths;
import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(VolcanicDepths.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, VolcanicDepths.MODID);

    public static final Supplier<CreativeModeTab> TAB = TABS.register("volcanic_depths", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.volcanic_depths"))
            .icon(() -> new ItemStack(ModBlocks.SUPERHEATED_MAGMA.get()))
            .displayItems((params, out) -> {
                out.accept(ModBlocks.ASHEN_STONE.get());
                out.accept(ModBlocks.ASH_LAYER.get());
                out.accept(ModBlocks.SCALDING_ROCK.get());
                out.accept(ModBlocks.SMOKING_VENT.get());
                out.accept(ModBlocks.SUPERHEATED_MAGMA.get());
            })
            .build());

    private ModItems() {}
}
