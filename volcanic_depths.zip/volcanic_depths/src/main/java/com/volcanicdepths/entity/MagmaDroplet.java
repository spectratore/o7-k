package com.volcanicdepths.entity;

import com.volcanicdepths.effects.VolcanicDamage;
import com.volcanicdepths.registry.ModParticles;
import com.volcanicdepths.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * A glob of molten rock thrown up by a geyser. Has no model: the client draws it purely with a short particle
 * trail, so it is nearly free to render. Short lifetime, and only a handful are spawned per eruption.
 */
public class MagmaDroplet extends ThrowableProjectile {
    private static final int MAX_AGE = 90;
    private static final float DAMAGE = 3.0F;

    public MagmaDroplet(EntityType<? extends MagmaDroplet> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            level().addParticle(ModParticles.EMBER.get(), getX(), getY(), getZ(), 0.0, 0.0, 0.0);
            if ((tickCount & 1) == 0) level().addParticle(ParticleTypes.FLAME, getX(), getY(), getZ(), 0.0, 0.0, 0.0);
            if (tickCount % 3 == 0) level().addParticle(ModParticles.SMOKE.get(), getX(), getY(), getZ(), 0.0, 0.01, 0.0);
        } else if (tickCount > MAX_AGE) {
            discard();
        }
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        return !(entity instanceof MagmaDroplet) && super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level() instanceof ServerLevel server) {
            Entity target = result.getEntity();
            if (!VolcanicDamage.isHeatImmune(target)) {
                target.hurt(VolcanicDamage.source(server, VolcanicDamage.MAGMA_DROPLET), DAMAGE);
                target.igniteForSeconds(3.0F);
            }
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) {
            level().broadcastEntityEvent(this, (byte) 3);
            level().playSound(null, blockPosition(), ModSounds.DROPLET_SIZZLE.get(), SoundSource.BLOCKS, 0.7F, 0.9F + random.nextFloat() * 0.3F);
            discard();
        }
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == 3) {
            for (int i = 0; i < 4; i++) {
                level().addParticle(ParticleTypes.LAVA, getX(), getY(), getZ(), 0.0, 0.0, 0.0);
            }
            level().addParticle(ModParticles.STEAM.get(), getX(), getY(), getZ(), 0.0, 0.03, 0.0);
        } else {
            super.handleEntityEvent(id);
        }
    }
}
