package com.volcanicdepths.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

/**
 * One cheap particle class for ash, embers, steam, smoke and heat haze. No collision physics: instead the
 * particle removes itself when it drifts into a solid block (so ash lands, smoke stops at ceilings).
 */
public class VolcanicParticle extends TextureSheetParticle {
    public enum Kind { ASH, EMBER, STEAM, SMOKE, HAZE }

    private final Kind kind;
    private final float phase;
    private float baseSize;

    protected VolcanicParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz,
                               Kind kind, SpriteSet sprites) {
        super(level, x, y, z);
        this.kind = kind;
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.hasPhysics = false;
        this.friction = 0.96F;
        this.phase = random.nextFloat() * 6.2831F;
        pickSprite(sprites);
        switch (kind) {
            case ASH -> {
                lifetime = 90 + random.nextInt(70);
                baseSize = 0.045F + random.nextFloat() * 0.04F;
                float g = 0.5F + random.nextFloat() * 0.3F;
                setColor(g, g * 0.97F, g * 0.94F);
                friction = 0.99F;
                yd += -0.012;
            }
            case EMBER -> {
                lifetime = 30 + random.nextInt(40);
                baseSize = 0.05F + random.nextFloat() * 0.04F;
                setColor(1.0F, 0.7F, 0.35F);
            }
            case STEAM -> {
                lifetime = 20 + random.nextInt(20);
                baseSize = 0.3F + random.nextFloat() * 0.15F;
                setColor(1F, 1F, 1F);
                alpha = 0.0F;
            }
            case SMOKE -> {
                lifetime = 60 + random.nextInt(60);
                baseSize = 0.35F + random.nextFloat() * 0.25F;
                float g = 0.1F + random.nextFloat() * 0.1F;
                setColor(g, g, g);
                friction = 0.97F;
            }
            case HAZE -> {
                lifetime = 14 + random.nextInt(14);
                baseSize = 0.7F + random.nextFloat() * 0.3F;
                setColor(1F, 0.9F, 0.8F);
            }
        }
    }

    @Override
    public void tick() {
        xo = x;
        yo = y;
        zo = z;
        if (age++ >= lifetime) {
            remove();
            return;
        }
        float t = (float) age / lifetime;
        switch (kind) {
            case ASH -> {
                xd += Math.sin((age + phase * 10) * 0.15) * 0.0008;
                zd += Math.cos((age + phase * 10) * 0.13) * 0.0008;
                yd = Math.max(yd - 0.0006, -0.035);
                alpha = t > 0.75F ? (1F - t) * 4F : 1F;
            }
            case EMBER -> {
                yd += 0.0025;
                xd += (random.nextFloat() - 0.5F) * 0.004;
                zd += (random.nextFloat() - 0.5F) * 0.004;
                alpha = 1F - t * t;
                float c = 1F - t;
                setColor(1.0F, 0.35F + 0.35F * c, 0.1F + 0.2F * c);
            }
            case STEAM -> alpha = 0.4F * Mth.clamp(Math.min(t * 6F, 1F - t), 0F, 1F) * 1.6F;
            case SMOKE -> {
                xd += Math.sin((age + phase * 10) * 0.08) * 0.0004;
                alpha = 0.55F * Mth.clamp(Math.min(t * 7F, (1F - t) * 1.4F), 0F, 1F);
            }
            case HAZE -> {
                yd += 0.0006;
                alpha = 0.13F * Mth.sin(t * Mth.PI);
            }
        }
        move(xd, yd, zd);
        xd *= friction;
        yd *= friction;
        zd *= friction;
        if ((age & 3) == 0) {
            BlockPos bp = BlockPos.containing(x, y, z);
            if (level.getBlockState(bp).isCollisionShapeFullBlock(level, bp)) remove();
        }
    }

    @Override
    public float getQuadSize(float partialTick) {
        float t = Mth.clamp((age + partialTick) / lifetime, 0F, 1F);
        return switch (kind) {
            case ASH -> baseSize;
            case EMBER -> baseSize * (1F - 0.6F * t);
            case STEAM -> baseSize * (0.6F + 1.4F * t);
            case SMOKE -> baseSize * (0.5F + 1.6F * Mth.sqrt(t));
            case HAZE -> baseSize * (0.8F + 0.6F * t);
        };
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return kind == Kind.EMBER ? LightTexture.FULL_BRIGHT : super.getLightColor(partialTick);
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final Kind kind;

        public Provider(SpriteSet sprites, Kind kind) {
            this.sprites = sprites;
            this.kind = kind;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new VolcanicParticle(level, x, y, z, vx, vy, vz, kind, sprites);
        }
    }
}
