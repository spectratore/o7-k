package com.volcanicdepths.client;

import com.volcanicdepths.VolcanicDepths;
import com.volcanicdepths.registry.ModEntities;
import com.volcanicdepths.registry.ModParticles;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

/** Mod-bus client registrations. */
@EventBusSubscriber(modid = VolcanicDepths.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    public static void registerParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.ASH.get(), s -> new VolcanicParticle.Provider(s, VolcanicParticle.Kind.ASH));
        event.registerSpriteSet(ModParticles.EMBER.get(), s -> new VolcanicParticle.Provider(s, VolcanicParticle.Kind.EMBER));
        event.registerSpriteSet(ModParticles.STEAM.get(), s -> new VolcanicParticle.Provider(s, VolcanicParticle.Kind.STEAM));
        event.registerSpriteSet(ModParticles.SMOKE.get(), s -> new VolcanicParticle.Provider(s, VolcanicParticle.Kind.SMOKE));
        event.registerSpriteSet(ModParticles.HAZE.get(), s -> new VolcanicParticle.Provider(s, VolcanicParticle.Kind.HAZE));
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.MAGMA_DROPLET.get(), NoopRenderer::new);
    }

    private ClientSetup() {}
}
