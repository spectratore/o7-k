package com.volcanicdepths.client;

import com.volcanicdepths.VolcanicDepths;
import com.volcanicdepths.effects.VolcanicEffects;
import com.volcanicdepths.registry.ModBiomes;
import com.volcanicdepths.registry.ModParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.material.FogType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * Biome-wide client ambience while the player is inside the Volcanic Depths: embers and haze above lava,
 * lava bubbling, steam, occasional ash clouds in big chambers and a gentle fog that limits visibility.
 *
 * <p>Budget: every 2nd tick, at most {@link #ATTEMPTS} random positions near the player are sampled and most
 * produce nothing, so this adds only a handful of particles per second.
 */
@EventBusSubscriber(modid = VolcanicDepths.MODID, value = Dist.CLIENT)
public final class VolcanicAmbience {
    private static final int ATTEMPTS = 8;
    private static final float FOG_FAR = 56.0F;

    /** Smoothed 0..1 "how volcanic is the place I'm standing in" value. */
    private static float intensity = 0F;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null) {
            intensity = 0F;
            return;
        }
        if (mc.isPaused()) return;

        boolean inside = level.getBiome(player.blockPosition()).is(ModBiomes.VOLCANIC_DEPTHS);
        intensity += ((inside ? 1F : 0F) - intensity) * 0.04F;
        if (!inside || (level.getGameTime() & 1L) != 0L) return;

        RandomSource r = level.random;
        BlockPos o = player.blockPosition();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int i = 0; i < ATTEMPTS; i++) {
            m.set(o.getX() + r.nextInt(29) - 14, o.getY() + r.nextInt(15) - 6, o.getZ() + r.nextInt(29) - 14);
            if (!level.getBlockState(m).isAir()) continue;
            sample(level, m, r);
        }
    }

    private static void sample(ClientLevel level, BlockPos pos, RandomSource r) {
        double x = pos.getX() + r.nextDouble(), z = pos.getZ() + r.nextDouble();
        if (level.getFluidState(pos.below()).is(FluidTags.LAVA)) {
            double surface = pos.getY() + 0.05;
            if (r.nextInt(3) == 0) {
                level.addParticle(ModParticles.EMBER.get(), x, surface + 0.1, z, (r.nextDouble() - 0.5) * 0.02, 0.03 + r.nextDouble() * 0.03, (r.nextDouble() - 0.5) * 0.02);
            }
            if (r.nextInt(10) == 0) { // bubbling / splashing
                level.addParticle(ParticleTypes.LAVA, x, surface, z, 0, 0, 0);
                level.playLocalSound(x, surface, z, SoundEvents.LAVA_POP, SoundSource.AMBIENT, 0.2F, 0.6F + r.nextFloat() * 0.4F, false);
            }
            if (r.nextInt(14) == 0) level.addParticle(ModParticles.HAZE.get(), x, surface + 0.3, z, 0, 0.04, 0);
            if (r.nextInt(45) == 0) { // small steam burst
                for (int i = 0; i < 3; i++) {
                    level.addParticle(ModParticles.STEAM.get(), x + (r.nextDouble() - 0.5) * 0.5, surface, z + (r.nextDouble() - 0.5) * 0.5, 0, 0.06, 0);
                }
            }
            return;
        }
        if (r.nextInt(70) == 0 && isLargeChamber(level, pos)) {
            VolcanicEffects.ashCloud(level, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, r);
        }
    }

    /** Cheap openness test: free space 5 blocks out in the four horizontal directions and 6 up. */
    private static boolean isLargeChamber(ClientLevel level, BlockPos pos) {
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos p = pos.relative(d, 5);
            if (level.getBlockState(p).isCollisionShapeFullBlock(level, p)) return false;
        }
        BlockPos up = pos.above(6);
        return !level.getBlockState(up).isCollisionShapeFullBlock(level, up);
    }

    /** Pulls the fog in while inside the biome, easing in and out as the player crosses its edge. */
    @SubscribeEvent
    public static void onRenderFog(ViewportEvent.RenderFog event) {
        if (intensity < 0.01F || event.getMode() != FogRenderer.FogMode.FOG_TERRAIN) return;
        if (event.getCamera().getFluidInCamera() != FogType.NONE) return;
        float far = Mth.lerp(intensity, event.getFarPlaneDistance(), Math.min(event.getFarPlaneDistance(), FOG_FAR));
        float near = Mth.lerp(intensity, event.getNearPlaneDistance(), Math.min(event.getNearPlaneDistance(), far * 0.3F));
        event.setFarPlaneDistance(far);
        event.setNearPlaneDistance(near);
        event.setCanceled(true);
    }

    private VolcanicAmbience() {}
}
