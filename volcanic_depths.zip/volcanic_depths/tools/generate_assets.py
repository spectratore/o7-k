#!/usr/bin/env python3
"""Generates every texture, model, blockstate and data JSON for Volcanic Depths.
Pure standard library. Run from the project root:  python3 tools/generate_assets.py
"""
import os, json, math, random, zlib, struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "src/main/resources")
A = os.path.join(RES, "assets/volcanic_depths")
D = os.path.join(RES, "data/volcanic_depths")
MC = os.path.join(RES, "data/minecraft")
NS = "volcanic_depths"


def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)


def write_png(path, rows):
    h, w = len(rows), len(rows[0])
    raw = b"".join(b"\x00" + bytes(c for px in row for c in px) for row in rows)

    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(png)


def clamp(v, lo=0, hi=255):
    return max(lo, min(hi, int(v)))


def tile_noise(size, cells, rng):
    g = [[rng.random() for _ in range(cells)] for _ in range(cells)]
    out = [[0.0] * size for _ in range(size)]
    for y in range(size):
        for x in range(size):
            fx, fy = x * cells / size, y * cells / size
            x0, y0 = int(fx) % cells, int(fy) % cells
            x1, y1 = (x0 + 1) % cells, (y0 + 1) % cells
            tx, ty = fx - int(fx), fy - int(fy)
            tx, ty = tx * tx * (3 - 2 * tx), ty * ty * (3 - 2 * ty)
            a = g[y0][x0] * (1 - tx) + g[y0][x1] * tx
            b = g[y1][x0] * (1 - tx) + g[y1][x1] * tx
            out[y][x] = a * (1 - ty) + b * ty
    return out


# ----------------------------------------------------------------------------- stone-like textures
def rock_texture(seed, base, spread, warm=0, speck_light=0.05, speck_dark=0.09):
    rng = random.Random(seed)
    n1, n2 = tile_noise(16, 4, rng), tile_noise(16, 8, rng)
    px = [[None] * 16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            v = base + (n1[y][x] - 0.5) * spread + (n2[y][x] - 0.5) * spread * 0.6
            r = rng.random()
            if r < speck_light:
                v += 36
            elif r < speck_light + speck_dark:
                v -= 18
            px[y][x] = [clamp(v + warm), clamp(v), clamp(v + 2), 255]
    return px


def add_cracks(px, seed, count, steps, hot=1.0, glow=True):
    rng = random.Random(seed)
    crack = set()
    for _ in range(count):
        x, y = rng.randrange(16), rng.randrange(16)
        dx, dy = rng.choice([-1, 0, 1]), rng.choice([-1, 0, 1]) or 1
        for _ in range(steps):
            crack.add((x % 16, y % 16))
            if rng.random() < 0.4:
                dx = rng.choice([-1, 0, 1])
            if rng.random() < 0.4:
                dy = rng.choice([-1, 0, 1])
            if dx == 0 and dy == 0:
                dy = 1
            x += dx
            y += dy
    if glow:
        for (cx, cy) in list(crack):
            for ox, oy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                p = ((cx + ox) % 16, (cy + oy) % 16)
                if p not in crack:
                    c = px[p[1]][p[0]]
                    px[p[1]][p[0]] = [clamp(c[0] * 0.45 + 130 * hot * 0.55), clamp(c[1] * 0.45 + 46 * hot * 0.55),
                                      clamp(c[2] * 0.45 + 18 * hot * 0.55), 255]
    for (cx, cy) in crack:
        t = rng.random()
        if t < 0.28:
            col = [255, 188, 64, 255]
        elif t < 0.7:
            col = [236, 108, 22, 255]
        else:
            col = [200, 70, 16, 255]
        px[cy][cx] = [clamp(col[0] * (0.55 + 0.45 * hot)), clamp(col[1] * (0.55 + 0.45 * hot)),
                      clamp(col[2] * (0.55 + 0.45 * hot)), 255]
    return px


def magma_frames(seed, heat, frames=4):
    rng = random.Random(seed)
    base = [(rng.uniform(0, 16), rng.uniform(0, 16), rng.uniform(0, 6.28)) for _ in range(7)]
    crust_noise = tile_noise(16, 8, rng)
    rows = []
    for f in range(frames):
        t = f / frames
        pts = []
        for (bx, by, ph) in base:
            a = ph + 2 * math.pi * t
            pts.append(((bx + 1.3 * math.cos(a)) % 16, (by + 1.3 * math.sin(a)) % 16))
        thr = 0.7 + 3.6 * heat
        for y in range(16):
            row = []
            for x in range(16):
                ds = []
                for (px_, py_) in pts:
                    for sx in (-16, 0, 16):
                        for sy in (-16, 0, 16):
                            ds.append(math.hypot(x + 0.5 - (px_ + sx), y + 0.5 - (py_ + sy)))
                ds.sort()
                edge = ds[1] - ds[0]
                if edge < thr:
                    m = (1 - edge / thr) * (0.55 + 0.6 * heat)
                    if m < 0.35:
                        c = (110 + 120 * m, 22 + 60 * m, 8)
                    elif m < 0.7:
                        k = (m - 0.35) / 0.35
                        c = (230 + 20 * k, 70 + 110 * k, 12 + 30 * k)
                    else:
                        k = min(1, (m - 0.7) / 0.3)
                        c = (255, 190 + 55 * k, 70 + 120 * k)
                    dim = 0.55 + 0.45 * min(1, heat * 1.6)
                    row.append([clamp(c[0] * dim), clamp(c[1] * dim), clamp(c[2] * dim), 255])
                else:
                    n = crust_noise[y][x]
                    glow = max(0, 1 - (edge - thr) / 1.4) * heat
                    row.append([clamp(26 + n * 20 + glow * 90), clamp(18 + n * 9 + glow * 26),
                                clamp(18 + n * 8 + glow * 8), 255])
            rows.append(row)
    return rows


def vent_top(active, seed=31):
    px = rock_texture(seed, 46, 22, warm=3)
    cx = cy = 7.5
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - cx, y - cy)
            if d < 4.8:
                if active:
                    k = 1 - d / 4.8
                    px[y][x] = [clamp(210 + 45 * k), clamp(90 + 120 * k), clamp(20 + 60 * k), 255]
                else:
                    px[y][x] = [12, 10, 12, 255]
            elif d < 6.3:
                k = (6.3 - d) / 1.5
                c = px[y][x]
                gl = (190, 70, 18) if active else (120, 48, 16)
                px[y][x] = [clamp(c[0] * (1 - k * .8) + gl[0] * k * .8), clamp(c[1] * (1 - k * .8) + gl[1] * k * .8),
                            clamp(c[2] * (1 - k * .8) + gl[2] * k * .8), 255]
    return px


def vent_side(seed=32):
    px = rock_texture(seed, 40, 20, warm=4)
    rng = random.Random(seed)
    for _ in range(3):  # soot streaks
        x = rng.randrange(16)
        for y in range(rng.randrange(0, 5), 16):
            c = px[y][x]
            px[y][x] = [clamp(c[0] * .6), clamp(c[1] * .6), clamp(c[2] * .6), 255]
    return add_cracks(px, seed + 1, 2, 9, hot=0.7)


# ----------------------------------------------------------------------------- particles
def blob(size, color, power, noise_amt, seed, max_alpha=255):
    rng = random.Random(seed)
    n = tile_noise(size, 4, rng)
    c = (size - 1) / 2
    rows = []
    for y in range(size):
        row = []
        for x in range(size):
            d = math.hypot(x - c, y - c) / (size / 2)
            d *= 1 + (n[y][x] - 0.5) * noise_amt
            a = max(0.0, 1 - d) ** power
            row.append([color[0], color[1], color[2], clamp(a * max_alpha)])
        rows.append(row)
    return rows


def ash_flake(seed):
    rng = random.Random(seed)
    rows = [[[0, 0, 0, 0] for _ in range(8)] for _ in range(8)]
    for _ in range(rng.randint(5, 8)):
        x, y = rng.randint(2, 5), rng.randint(2, 5)
        g = rng.randint(120, 175)
        rows[y][x] = [g, g - 2, g - 4, 255]
        for ox, oy in ((1, 0), (0, 1), (-1, 0), (0, -1)):
            if rng.random() < 0.3 and rows[y + oy][x + ox][3] == 0:
                rows[y + oy][x + ox] = [g - 20, g - 22, g - 24, 170]
    return rows


def ember(seed):
    rows = []
    c = 3.5
    for y in range(8):
        row = []
        for x in range(8):
            d = math.hypot(x - c, y - c)
            if d < 1.0:
                row.append([255, 240, 180, 255])
            elif d < 2.0:
                row.append([255, 160, 50, 235])
            elif d < 3.0:
                row.append([210, 70, 14, 110])
            else:
                row.append([0, 0, 0, 0])
        rows.append(row)
    return rows


def build_assets():
    # --- block textures
    T = os.path.join(A, "textures/block")
    write_png(os.path.join(T, "ashen_stone.png"), rock_texture(1, 48, 24, warm=2))
    scald = add_cracks(rock_texture(2, 38, 20, warm=6), 7, 3, 20)
    write_png(os.path.join(T, "scalding_rock.png"), scald)
    phases = {"dormant": (0.35, 20), "rumbling": (0.55, 10), "charging": (0.8, 5), "erupting": (1.0, 3),
              "cooling": (0.12, 40)}
    for i, (name, (heat, ft)) in enumerate(phases.items()):
        write_png(os.path.join(T, f"superheated_magma_{name}.png"), magma_frames(100 + i, heat))
        wj(os.path.join(T, f"superheated_magma_{name}.png.mcmeta"), {"animation": {"frametime": ft, "interpolate": True}})
    write_png(os.path.join(T, "smoking_vent_top.png"), vent_top(False))
    write_png(os.path.join(T, "smoking_vent_top_active.png"), vent_top(True))
    write_png(os.path.join(T, "smoking_vent_side.png"), vent_side())
    write_png(os.path.join(T, "ash_layer.png"), rock_texture(5, 112, 14, warm=2, speck_light=0.06, speck_dark=0.07))

    # --- particle textures
    P = os.path.join(A, "textures/particle")
    for i in range(2):
        write_png(os.path.join(P, f"ash_{i}.png"), ash_flake(10 + i))
        write_png(os.path.join(P, f"smoke_{i}.png"), blob(16, (46, 44, 46), 1.1, 0.7, 20 + i, 235))
    write_png(os.path.join(P, "ember_0.png"), ember(0))
    write_png(os.path.join(P, "steam_0.png"), blob(16, (242, 242, 242), 1.4, 0.6, 30, 210))
    write_png(os.path.join(P, "haze_0.png"), blob(16, (255, 236, 215), 2.0, 0.4, 40, 120))
    for name, texs in {"ash": ["ash_0", "ash_1"], "smoke": ["smoke_0", "smoke_1"], "ember": ["ember_0"],
                       "steam": ["steam_0"], "haze": ["haze_0"]}.items():
        wj(os.path.join(A, f"particles/{name}.json"), {"textures": [f"{NS}:{t}" for t in texs]})

    # --- blockstates & models
    B = os.path.join(A, "models/block")
    I = os.path.join(A, "models/item")
    S = os.path.join(A, "blockstates")

    def cube_all(name, tex):
        wj(os.path.join(B, name + ".json"), {"parent": "minecraft:block/cube_all", "textures": {"all": f"{NS}:block/{tex}"}})

    cube_all("ashen_stone", "ashen_stone")
    cube_all("scalding_rock", "scalding_rock")
    wj(os.path.join(S, "ashen_stone.json"), {"variants": {"": [
        {"model": f"{NS}:block/ashen_stone"}, {"model": f"{NS}:block/ashen_stone", "y": 90},
        {"model": f"{NS}:block/ashen_stone", "y": 180}, {"model": f"{NS}:block/ashen_stone", "y": 270}]}})
    wj(os.path.join(S, "scalding_rock.json"), {"variants": {"": {"model": f"{NS}:block/scalding_rock"}}})

    multipart = []
    for name in phases:
        cube_all(f"superheated_magma_{name}", f"superheated_magma_{name}")
        multipart.append({"when": {"phase": name}, "apply": {"model": f"{NS}:block/superheated_magma_{name}"}})
    wj(os.path.join(S, "superheated_magma.json"), {"multipart": multipart})

    for suffix, top in (("", "smoking_vent_top"), ("_active", "smoking_vent_top_active")):
        wj(os.path.join(B, f"smoking_vent{suffix}.json"), {
            "parent": "minecraft:block/cube_bottom_top",
            "textures": {"top": f"{NS}:block/{top}", "bottom": f"{NS}:block/ashen_stone",
                         "side": f"{NS}:block/smoking_vent_side"}})
    wj(os.path.join(S, "smoking_vent.json"), {"variants": {
        "active=false": {"model": f"{NS}:block/smoking_vent"},
        "active=true": {"model": f"{NS}:block/smoking_vent_active"}}})

    variants = {}
    for layers in range(1, 9):
        h = layers * 2
        faces = {
            "down": {"uv": [0, 0, 16, 16], "texture": "#texture", "cullface": "down"},
            "up": {"uv": [0, 0, 16, 16], "texture": "#texture"},
        }
        for side in ("north", "south", "east", "west"):
            faces[side] = {"uv": [0, 16 - h, 16, 16], "texture": "#texture", "cullface": side}
        if h == 16:
            faces["up"]["cullface"] = "up"
        wj(os.path.join(B, f"ash_height{h}.json"), {
            "textures": {"particle": f"{NS}:block/ash_layer", "texture": f"{NS}:block/ash_layer"},
            "elements": [{"from": [0, 0, 0], "to": [16, h, 16], "faces": faces}]})
        variants[f"layers={layers}"] = {"model": f"{NS}:block/ash_height{h}"}
    wj(os.path.join(S, "ash_layer.json"), {"variants": variants})

    items = {"ashen_stone": "ashen_stone", "scalding_rock": "scalding_rock",
             "superheated_magma": "superheated_magma_dormant", "smoking_vent": "smoking_vent",
             "ash_layer": "ash_height2"}
    for item, model in items.items():
        wj(os.path.join(I, item + ".json"), {"parent": f"{NS}:block/{model}"})

    # --- lang
    lang = {
        "itemGroup.volcanic_depths": "Volcanic Depths",
        "block.volcanic_depths.ashen_stone": "Ashen Stone",
        "block.volcanic_depths.scalding_rock": "Scalding Rock",
        "block.volcanic_depths.superheated_magma": "Superheated Magma",
        "block.volcanic_depths.smoking_vent": "Smoking Vent",
        "block.volcanic_depths.ash_layer": "Volcanic Ash",
        "biome.volcanic_depths.volcanic_depths": "Volcanic Depths",
        "entity.volcanic_depths.magma_droplet": "Magma Droplet",
        "subtitles.volcanic_depths.ambient.rumble": "Distant rumbling",
        "subtitles.volcanic_depths.ambient.mood": "Lava crackles",
        "subtitles.volcanic_depths.magma.rumble": "Magma rumbles",
        "subtitles.volcanic_depths.magma.charge": "Magma hisses",
        "subtitles.volcanic_depths.geyser.erupt": "Magma geyser erupts",
        "subtitles.volcanic_depths.geyser.hiss": "Geyser hisses",
        "subtitles.volcanic_depths.vent.warn": "Vent hisses",
        "subtitles.volcanic_depths.vent.burst": "Vent bursts",
        "subtitles.volcanic_depths.droplet.sizzle": "Magma sizzles",
        "death.attack.volcanic_depths.scalding": "%1$s was scalded by volcanic rock",
        "death.attack.volcanic_depths.scalding.player": "%1$s was scalded to death while fighting %2$s",
        "death.attack.volcanic_depths.geyser": "%1$s was caught in a magma geyser",
        "death.attack.volcanic_depths.geyser.player": "%1$s was caught in a magma geyser while fighting %2$s",
        "death.attack.volcanic_depths.magma_droplet": "%1$s was struck by a magma droplet",
        "death.attack.volcanic_depths.magma_droplet.player": "%1$s was struck by a magma droplet while fighting %2$s",
    }
    wj(os.path.join(A, "lang/en_us.json"), lang)

    # --- sounds: every event re-uses a vanilla sound event, so no audio files and no tonal/beeping sounds.
    def ev(name, volume=1.0, pitch=1.0, weight=1):
        return {"name": name, "type": "event", "volume": volume, "pitch": pitch, "weight": weight}

    sounds = {
        "ambient.rumble": ("ambient.rumble", [ev("minecraft:entity.generic.explode", 0.22, 0.45, 3),
                                              ev("minecraft:block.deepslate.break", 0.6, 0.5, 2)]),
        "ambient.mood": ("ambient.mood", [ev("minecraft:block.lava.ambient", 1.0, 0.8, 3),
                                          ev("minecraft:block.lava.pop", 0.7, 0.7, 1)]),
        "magma.rumble": ("magma.rumble", [ev("minecraft:entity.generic.explode", 0.3, 0.5),
                                          ev("minecraft:block.deepslate.break", 0.8, 0.5)]),
        "magma.charge": ("magma.charge", [ev("minecraft:block.fire.extinguish", 0.9, 0.7),
                                          ev("minecraft:block.lava.extinguish", 0.8, 0.6)]),
        "geyser.erupt": ("geyser.erupt", [ev("minecraft:entity.generic.explode", 0.9, 0.75)]),
        "geyser.hiss": ("geyser.hiss", [ev("minecraft:block.lava.extinguish", 0.9, 0.5),
                                        ev("minecraft:block.fire.extinguish", 0.8, 0.6)]),
        "vent.warn": ("vent.warn", [ev("minecraft:block.fire.extinguish", 0.5, 1.1)]),
        "vent.burst": ("vent.burst", [ev("minecraft:block.lava.extinguish", 0.8, 0.9),
                                      ev("minecraft:block.fire.extinguish", 0.8, 0.8)]),
        "droplet.sizzle": ("droplet.sizzle", [ev("minecraft:block.fire.extinguish", 0.5, 1.3)]),
    }
    wj(os.path.join(A, "sounds.json"), {k: {"subtitle": f"subtitles.{NS}.{sub}", "sounds": s}
                                        for k, (sub, s) in sounds.items()})

    # =============================================================== DATA
    # loot tables
    def self_drop(name, item=None):
        wj(os.path.join(D, f"loot_table/blocks/{name}.json"), {
            "type": "minecraft:block",
            "pools": [{"bonus_rolls": 0.0, "conditions": [{"condition": "minecraft:survives_explosion"}],
                       "entries": [{"type": "minecraft:item", "name": f"{NS}:{item or name}"}], "rolls": 1.0}],
            "random_sequence": f"{NS}:blocks/{name}"})

    for n in ("ashen_stone", "scalding_rock", "superheated_magma", "smoking_vent"):
        self_drop(n)
    children = []
    for layers in range(1, 9):
        children.append({
            "type": "minecraft:item", "name": f"{NS}:ash_layer",
            "conditions": [{"condition": "minecraft:block_state_property", "block": f"{NS}:ash_layer",
                            "properties": {"layers": str(layers)}}],
            "functions": [{"function": "minecraft:set_count", "count": float(layers)}]})
    wj(os.path.join(D, "loot_table/blocks/ash_layer.json"), {
        "type": "minecraft:block",
        "pools": [{"rolls": 1.0, "entries": [{"type": "minecraft:alternatives", "children": children}]}],
        "random_sequence": f"{NS}:blocks/ash_layer"})

    # tags
    def tag(path, values):
        wj(os.path.join(MC, path), {"replace": False, "values": values})

    tag("tags/block/mineable/pickaxe.json", [f"{NS}:{n}" for n in ("ashen_stone", "scalding_rock", "superheated_magma", "smoking_vent")])
    tag("tags/block/mineable/shovel.json", [f"{NS}:ash_layer"])
    tag("tags/block/needs_stone_tool.json", [f"{NS}:{n}" for n in ("ashen_stone", "scalding_rock", "smoking_vent")])
    tag("tags/block/needs_iron_tool.json", [f"{NS}:superheated_magma"])
    tag("tags/damage_type/is_fire.json", [f"{NS}:scalding", f"{NS}:geyser", f"{NS}:magma_droplet"])
    tag("tags/worldgen/biome/is_overworld.json", [f"{NS}:volcanic_depths"])
    wj(os.path.join(RES, "data/c/tags/worldgen/biome/is_cave.json"), {"replace": False, "values": [f"{NS}:volcanic_depths"]})
    wj(os.path.join(RES, "data/c/tags/worldgen/biome/is_underground.json"), {"replace": False, "values": [f"{NS}:volcanic_depths"]})

    # damage types (is_fire tag => Fire Resistance and fire-immune mobs are protected automatically)
    for n in ("scalding", "geyser", "magma_droplet"):
        wj(os.path.join(D, f"damage_type/{n}.json"), {
            "exhaustion": 0.1, "message_id": f"{NS}.{n}", "scaling": "when_caused_by_living_non_player", "effects": "burning"})

    # configured + placed features
    def configured(name, ftype, cfg):
        wj(os.path.join(D, f"worldgen/configured_feature/{name}.json"), {"type": f"{NS}:{ftype}", "config": cfg})

    def placed(name, placement):
        wj(os.path.join(D, f"worldgen/placed_feature/{name}.json"), {"feature": f"{NS}:{name}", "placement": placement})

    def hr(lo, hi):
        return {"type": "minecraft:height_range", "height": {
            "type": "minecraft:uniform", "min_inclusive": {"absolute": lo}, "max_inclusive": {"absolute": hi}}}

    def count(n):
        return {"type": "minecraft:count", "count": n}

    def count_range(a, b):
        return {"type": "minecraft:count", "count": {"type": "minecraft:uniform", "min_inclusive": a, "max_inclusive": b}}

    sq, biome = {"type": "minecraft:in_square"}, {"type": "minecraft:biome"}
    configured("strata", "strata", {})
    placed("strata", [])
    formations = {  # name: placement
        "chamber": [{"type": "minecraft:rarity_filter", "chance": 6}, sq, hr(-48, 10), biome],
        "lava_pool": [count(4), sq, hr(-60, 30), biome],
        "lava_fall": [{"type": "minecraft:rarity_filter", "chance": 3}, sq, hr(-50, 40), biome],
        "pillar": [count_range(6, 10), sq, hr(-60, 40), biome],
        "chimney": [count(3), sq, hr(-60, 30), biome],
        "vent": [count(4), sq, hr(-60, 30), biome],
        "scalding_cluster": [count(5), sq, hr(-60, 30), biome],
        "magma_formation": [count(3), sq, hr(-60, 20), biome],
        "ash_mound": [count(6), sq, hr(-60, 40), biome],
    }
    for name, placement in formations.items():
        configured(name, "formation", {"kind": name})
        placed(name, placement)

    # biome
    def pf(n):
        return f"{NS}:{n}"

    ores = ["ore_coal_upper", "ore_coal_lower", "ore_iron_upper", "ore_iron_middle", "ore_iron_small", "ore_gold",
            "ore_gold_lower", "ore_redstone", "ore_redstone_lower", "ore_diamond", "ore_diamond_large",
            "ore_diamond_buried", "ore_lapis", "ore_lapis_buried", "ore_copper"]
    features = [[] for _ in range(11)]
    features[6] = [f"minecraft:{o}" for o in ores]
    features[7] = [pf(n) for n in ("chamber", "strata", "lava_pool", "lava_fall", "pillar", "chimney", "vent",
                                   "scalding_cluster", "magma_formation", "ash_mound")]
    wj(os.path.join(D, "worldgen/biome/volcanic_depths.json"), {
        "has_precipitation": False,
        "temperature": 2.0,
        "downfall": 0.0,
        "effects": {
            "fog_color": 0x2A1612, "sky_color": 0x3A1A14, "water_color": 0x4A4A52, "water_fog_color": 0x1A1A20,
            "particle": {"probability": 0.003, "options": {"type": f"{NS}:ash"}},
            "mood_sound": {"sound": f"{NS}:ambient.mood", "tick_delay": 6000, "block_search_extent": 8, "offset": 2.0},
            "additions_sound": {"sound": f"{NS}:ambient.rumble", "tick_chance": 0.0012},
        },
        "spawners": {
            "monster": [{"type": "minecraft:magma_cube", "weight": 6, "minCount": 1, "maxCount": 2}],
            "creature": [], "ambient": [], "axolotls": [], "underground_water_creature": [],
            "water_creature": [], "water_ambient": [], "misc": [],
        },
        "spawn_costs": {},
        "carvers": ["minecraft:cave", "minecraft:cave_extra_underground", "minecraft:canyon"],
        "features": features,
    })


if __name__ == "__main__":
    build_assets()
    print("generated")
